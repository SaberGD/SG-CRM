# Urology Waiting List Manager

A comprehensive surgical waiting list management system for urology departments.

## Tech Stack
- **React 19** with **Vite**
- **Firebase Firestore** for database
- **Firebase Authentication** (Google SSO Only)
- **Firebase Storage** for medical scans and documents
- **Tailwind CSS 4** for styling
- **Framer Motion** for animations
- **jsPDF & XLSX** for reporting

## Getting Started
1. **Login**: Use your Google account to sign in.
2. **Access**: This is an invitation-only system. Ensure your email is added to the `invitations` collection by an admin.
3. **Roles**:
   - **Admin**: Full access, user management, invitations.
   - **Doctor**: View patients, clinical diagnosis, notes, status management.
   - **Nurse**: View waiting lists, nursing notes, prep status.
   - **Coordinator**: Add patients, schedule operations, contact management.

## Seeding Sample Data
If you are an admin, go to **Settings** and click **Seed Sample Data** to populate the system with:
- Default department labels.
- Sample patients with medical histories.
- Pre-defined invitations.

## Key Features
- **Departmental Segregation**: Four modules (Onco-urology, Andrology, Female, Pediatric).
- **Activity Log**: Every action is audited and visible to admins.
- **Reporting**: Export surgical lists to PDF or Excel.
- **WhatsApp Integration**: One-click contact for patient coordination.
- **Real-time updates**: Collaborative data synchronization.

## Security
Firestore security rules are strictly enforced to protect patient PII and ensure role-based clinical data isolation.
