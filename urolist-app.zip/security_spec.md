# Security Specification for Urology Waiting List Manager

## Data Invariants
1. Patients must belong to one of the 4 defined urology departments.
2. Every patient update must be logged (implemented via client service with rule enforcement where possible).
3. Access is strictly invitation-only.
4. Doctors can only modify clinical fields (diagnosis, notes, status).
5. Admins can manage users and invitations.

## The Dirty Dozen (Payloads that should fail)
1. **Uninvited Login**: An unauthenticated user session trying to create a profile without an invitation.
2. **Role Escalation**: A nurse trying to change their own role to 'admin'.
3. **Ghost Patient**: Creating a patient record without a valid department.
4. **Identity Spoofing**: User A trying to update a note written by User B.
5. **Unauthorized Access**: A coordinator trying to delete a patient record (only Admin can delete).
6. **Bypassing Invitation**: Trying to create an 'invitation' as a 'doctor' role.
7. **Junk ID**: Creating a patient with a 2MB document ID.
8. **Clinical Tampering**: A coordinator trying to change a 'diagnosis' field (only Doctor/Admin).
9. **History Erasure**: Trying to update `createdAt` field on an existing patient.
10. **Shadow Field**: Adding a `isVerified: true` field to a patient document that isn't in the schema.
11. **Negative Age**: Creating a patient with `age: -5`.
12. **Future Creation**: Setting `createdAt` to a future date manually.

## Test Runner (Logic Verification)
Tests will be implemented to ensure `PERMISSION_DENIED` for the above scenarios.
