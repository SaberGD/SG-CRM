import React, { useState } from 'react';
import { 
  X, 
  User, 
  MapPin, 
  Phone, 
  IdCard, 
  FileText, 
  Activity, 
  Shield, 
  AlertCircle,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Patient, DepartmentType, InsuranceType, PriorityLevel, OperationStatus } from '../types';
import { patientService } from '../services/firestore';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { cn } from '../lib/utils';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';

interface PatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  editPatient?: Patient | null;
}

const AddPatientModal: React.FC<PatientModalProps> = ({ isOpen, onClose, editPatient }) => {
  const { profile } = useAuth();
  const [formData, setFormData] = useState({
    fullName: editPatient?.fullName || '',
    age: editPatient?.age || 0,
    gender: editPatient?.gender || 'Male' as any,
    address: editPatient?.address || '',
    phoneNumber: editPatient?.phoneNumber || '',
    secondaryPhoneNumbers: editPatient?.secondaryPhoneNumbers || [] as string[],
    hasWhatsapp: editPatient?.hasWhatsapp || false,
    whatsappNumber: editPatient?.whatsappNumber || '',
    nationalId: editPatient?.nationalId || '',
    department: editPatient?.department || 'Onco-urology' as DepartmentType,
    diagnosis: editPatient?.diagnosis || '',
    insuranceType: editPatient?.insuranceType || 'State Funding' as InsuranceType,
    insuranceOtherDetails: editPatient?.insuranceOtherDetails || '',
    priorityLevel: editPatient?.priorityLevel || 'Routine' as PriorityLevel,
    operationStatus: editPatient?.operationStatus || 'Waiting' as OperationStatus,
    scheduledDate: editPatient?.scheduledDate ? (editPatient.scheduledDate instanceof Date ? editPatient.scheduledDate.toISOString().split('T')[0] : (editPatient.scheduledDate.toDate ? editPatient.scheduledDate.toDate().toISOString().split('T')[0] : '')) : '',
    labels: editPatient?.labels || [] as string[],
    attachments: (editPatient?.attachments || []).map(a => ({ description: '', ...a })),
  });

  const [countryCode, setCountryCode] = useState(editPatient?.phoneNumber?.startsWith('+') ? (editPatient.phoneNumber.startsWith('+2') && !editPatient.phoneNumber.startsWith('+20') ? '+2' : editPatient.phoneNumber.substring(0, 4)) : '+2');
  const [isWhatsappSame, setIsWhatsappSame] = useState(editPatient ? editPatient.whatsappNumber === editPatient.phoneNumber : true);

  // Re-initialize form when editPatient changes or modal opens
  React.useEffect(() => {
    if (editPatient) {
      const p = editPatient;
      setFormData({
        fullName: p.fullName,
        age: p.age,
        gender: p.gender,
        address: p.address,
        phoneNumber: p.phoneNumber.replace(/^\+\d{1,4}/, ''), // relative number for field
        secondaryPhoneNumbers: p.secondaryPhoneNumbers?.map(n => n.replace(/^\+\d{1,4}/, '')) || [],
        hasWhatsapp: p.hasWhatsapp,
        whatsappNumber: p.whatsappNumber?.replace(/^\+\d{1,4}/, '') || '',
        nationalId: p.nationalId,
        department: p.department,
        diagnosis: p.diagnosis,
        insuranceType: p.insuranceType,
        insuranceOtherDetails: p.insuranceOtherDetails || '',
        priorityLevel: p.priorityLevel,
        operationStatus: p.operationStatus,
        scheduledDate: p.scheduledDate ? (p.scheduledDate instanceof Date ? p.scheduledDate.toISOString().split('T')[0] : (p.scheduledDate.toDate ? p.scheduledDate.toDate().toISOString().split('T')[0] : '')) : '',
        labels: p.labels || [],
        attachments: (p.attachments || []).map(a => ({ description: '', ...a })),
      });
      setCountryCode(p.phoneNumber.startsWith('+') ? (p.phoneNumber.startsWith('+2') && !p.phoneNumber.startsWith('+20') ? '+2' : (p.phoneNumber.startsWith('+966') ? '+966' : p.phoneNumber.substring(0, 4))) : '+2');
      setIsWhatsappSame(!p.whatsappNumber || p.whatsappNumber === p.phoneNumber);
    } else {
      setFormData({
        fullName: '',
        age: 0,
        gender: 'Male',
        address: '',
        phoneNumber: '',
        secondaryPhoneNumbers: [],
        hasWhatsapp: false,
        whatsappNumber: '',
        nationalId: '',
        department: 'Onco-urology',
        diagnosis: '',
        insuranceType: 'State Funding',
        insuranceOtherDetails: '',
        priorityLevel: 'Routine',
        operationStatus: 'Waiting',
        scheduledDate: '',
        labels: [],
        attachments: [],
      });
      setCountryCode('+2');
      setIsWhatsappSame(true);
    }
  }, [editPatient, isOpen]);

  const addSecondaryPhone = () => {
    setFormData(prev => ({
      ...prev,
      secondaryPhoneNumbers: [...prev.secondaryPhoneNumbers, '']
    }));
  };

  const updateSecondaryPhone = (index: number, value: string) => {
    const newPhones = [...formData.secondaryPhoneNumbers];
    newPhones[index] = value;
    setFormData({ ...formData, secondaryPhoneNumbers: newPhones });
  };

  const removeSecondaryPhone = (index: number) => {
    setFormData(prev => ({
      ...prev,
      secondaryPhoneNumbers: prev.secondaryPhoneNumbers.filter((_, i) => i !== index)
    }));
  };

  const addAttachment = () => {
    setFormData(prev => ({
      ...prev,
      attachments: [...prev.attachments, { name: '', url: '', type: 'Link', description: '' }]
    }));
  };

  const updateAttachment = (index: number, field: string, value: string) => {
    const newAttachments = [...formData.attachments];
    newAttachments[index] = { ...newAttachments[index], [field]: value };
    setFormData({ ...formData, attachments: newAttachments });
  };

  const removeAttachment = (index: number) => {
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    // Validation
    const phoneRegex = /^\d{7,15}$/;
    const purePhone = formData.phoneNumber.replace(/\D/g, '');
    if (!phoneRegex.test(purePhone)) {
      toast.error("Please enter a valid phone number");
      return;
    }

    const finalPhone = `${countryCode}${purePhone}`;
    let finalWhatsapp = '';
    if (formData.hasWhatsapp) {
      if (isWhatsappSame) {
        finalWhatsapp = finalPhone;
      } else {
        const pureWhatsapp = formData.whatsappNumber.replace(/\D/g, '');
        if (!pureWhatsapp) {
          toast.error("Please enter a WhatsApp number");
          return;
        }
        finalWhatsapp = `${countryCode}${pureWhatsapp}`;
      }
    }

    // Duplicate Check - Only if adding new or if ID/Phone changed significantly
    if (!editPatient) {
      const checkingToast = toast.loading("Checking for duplicates...");
      try {
        const qPhone = query(collection(db, 'patients'), where('phoneNumber', '==', finalPhone));
        const phoneSnap = await getDocs(qPhone);
        
        let foundDuplicate = phoneSnap.docs.length > 0;
        let duplicateReason = "Phone Number";

        if (!foundDuplicate && formData.nationalId) {
          const qId = query(collection(db, 'patients'), where('nationalId', '==', formData.nationalId));
          const idSnap = await getDocs(qId);
          if (idSnap.docs.length > 0) {
            foundDuplicate = true;
            duplicateReason = "National ID";
          }
        }

        if (foundDuplicate) {
          toast.dismiss(checkingToast);
          const confirm = window.confirm(`Patient with this ${duplicateReason} already exists. Do you want to add this record anyway?`);
          if (!confirm) return;
        }
      } catch (err) {
        console.error("Duplicate check failed:", err);
      }
      toast.dismiss(checkingToast);
    }

    // Secondary phones processing
    const finalSecondaryPhones = formData.secondaryPhoneNumbers
      .map(p => p.replace(/\D/g, ''))
      .filter(p => p.length >= 7)
      .map(p => `${countryCode}${p}`);

    const loadingToast = toast.loading(editPatient ? "Updating patient record..." : "Saving patient record...");
    try {
      const patientData = {
        ...formData,
        phoneNumber: finalPhone,
        whatsappNumber: finalWhatsapp,
        secondaryPhoneNumbers: finalSecondaryPhones,
        scheduledDate: formData.operationStatus === 'Scheduled' && formData.scheduledDate ? new Date(formData.scheduledDate) : null,
        attachments: formData.attachments.filter(a => a.url).map(a => ({
          ...a,
          uploadedAt: a.uploadedAt || new Date().toISOString(),
          uploadedBy: a.uploadedBy || profile.displayName,
          uploaderRole: a.uploaderRole || (profile.role as any)
        })),
        updatedAt: new Date(),
      };

      if (editPatient?.id) {
        await patientService.update(editPatient.id, patientData);
        toast.success("Patient updated successfully", { id: loadingToast });
      } else {
        await patientService.create({
          ...patientData,
          createdBy: profile.uid,
          createdByName: profile.displayName,
          createdByRole: profile.role as any,
          createdAt: new Date(),
        });
        toast.success("Patient added successfully", { id: loadingToast });
      }
      
      onClose();
      // Reset form
      setFormData({
        fullName: '',
        age: 0,
        gender: 'Male',
        address: '',
        phoneNumber: '',
        secondaryPhoneNumbers: [],
        hasWhatsapp: false,
        whatsappNumber: '',
        nationalId: '',
        department: 'Onco-urology',
        diagnosis: '',
        insuranceType: 'State Funding',
        insuranceOtherDetails: '',
        priorityLevel: 'Routine',
        operationStatus: 'Waiting',
        scheduledDate: '',
        labels: [],
        attachments: [],
      });
      setCountryCode('+2');
      setIsWhatsappSame(true);
    } catch (err) {
      toast.error("Failed to add patient", { id: loadingToast });
    }
  };

  const countries = [
    { code: '+2', name: 'Egypt', flag: '🇪🇬' },
    { code: '+966', name: 'KSA', flag: '🇸🇦' },
    { code: '+971', name: 'UAE', flag: '🇦🇪' },
    { code: '+965', name: 'Kuwait', flag: '🇰🇼' },
    { code: '+974', name: 'Qatar', flag: '🇶🇦' },
    { code: '+1', name: 'USA', flag: '🇺🇸' },
    { code: '+44', name: 'UK', flag: '🇬🇧' },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[100]"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl max-h-[90vh] bg-white rounded-[2.5rem] shadow-2xl z-[110] flex flex-col overflow-hidden border border-slate-100"
          >
            <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-white shrink-0">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-100">
                  {editPatient ? <Activity className="w-6 h-6" /> : <User className="w-6 h-6" />}
                </div>
                <div>
                  <h2 className="text-2xl font-extrabold text-slate-900">{editPatient ? 'Edit Patient Record' : 'Add New Patient'}</h2>
                  <p className="text-sm font-medium text-slate-400">
                    {editPatient ? `Updating records for ${editPatient.fullName}` : 'Register a new surgical candidate in the system.'}
                  </p>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="p-3 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-2xl transition-all"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-10 space-y-12">
              {/* Personal Information */}
              <section className="space-y-6">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <IdCard className="w-4 h-4" /> Personal Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Full Name <span className="text-red-500">*</span></label>
                    <input 
                      required
                      value={formData.fullName}
                      onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                      placeholder="e.g., John Alexander Smith"
                      className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1 flex flex-col">
                      <span>National ID</span>
                      <span className="text-[10px] text-slate-400 font-medium">(Optional)</span>
                    </label>
                    <input 
                      value={formData.nationalId}
                      onChange={(e) => setFormData({...formData, nationalId: e.target.value})}
                      placeholder="ID Number"
                      className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Age <span className="text-red-500">*</span></label>
                    <input 
                      type="number"
                      required
                      value={formData.age}
                      onChange={(e) => setFormData({...formData, age: parseInt(e.target.value)})}
                      className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Gender <span className="text-red-500">*</span></label>
                    <div className="flex gap-2 bg-slate-50 p-1 rounded-2xl">
                      {['Male', 'Female'].map(g => (
                        <button
                          key={g}
                          type="button"
                          onClick={() => setFormData({...formData, gender: g as any})}
                          className={cn(
                            "flex-1 py-3 rounded-xl text-sm font-bold transition-all",
                            formData.gender === g ? "bg-white text-blue-600 shadow-sm" : "text-slate-400 hover:text-slate-600"
                          )}
                        >
                          {g}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Phone Number <span className="text-red-500">*</span></label>
                    <div className="flex flex-col gap-3">
                      <div className="flex gap-2">
                        <select 
                          value={countryCode}
                          onChange={(e) => setCountryCode(e.target.value)}
                          className="w-24 px-3 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 focus:ring-2 focus:ring-blue-500/20 transition-all font-bold appearance-none cursor-pointer text-center"
                        >
                          {countries.map(c => (
                            <option key={c.code} value={c.code}>{c.flag} {c.code}</option>
                          ))}
                        </select>
                        <input 
                          required
                          value={formData.phoneNumber}
                          onChange={(e) => setFormData({...formData, phoneNumber: e.target.value})}
                          placeholder="Primary Phone"
                          className="flex-1 px-6 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                        />
                      </div>
                      
                      {formData.secondaryPhoneNumbers.map((phone, i) => (
                        <motion.div 
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          key={i} 
                          className="flex gap-2"
                        >
                          <div className="w-24 px-3 py-4 bg-slate-50 rounded-2xl text-slate-400 font-bold flex items-center justify-center">
                            {countryCode}
                          </div>
                          <input 
                            value={phone}
                            onChange={(e) => updateSecondaryPhone(i, e.target.value)}
                            placeholder="Secondary Phone"
                            className="flex-1 px-6 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                          />
                          <button 
                            type="button"
                            onClick={() => removeSecondaryPhone(i)}
                            className="p-4 text-red-400 hover:text-red-600 transition-colors"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        </motion.div>
                      ))}

                      <button 
                        type="button"
                        onClick={addSecondaryPhone}
                        className="flex items-center gap-2 text-sm font-bold text-blue-600 hover:text-blue-700 w-fit ml-1"
                      >
                        <Plus className="w-4 h-4" /> Add another phone number
                      </button>
                    </div>
                  </div>
                  <div className="space-y-2 lg:col-span-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">WhatsApp Availability</label>
                    <div className="flex flex-col gap-4 p-4 bg-slate-50 rounded-2xl">
                      <div className="flex items-center gap-4">
                        <label className="flex items-center gap-3 cursor-pointer">
                          <input 
                            type="checkbox"
                            checked={formData.hasWhatsapp}
                            onChange={(e) => setFormData({...formData, hasWhatsapp: e.target.checked})}
                            className="w-5 h-5 rounded-lg border-slate-300 text-green-600 focus:ring-green-500"
                          />
                          <span className="text-sm font-bold text-slate-600">Has WhatsApp?</span>
                        </label>
                        
                        {formData.hasWhatsapp && (
                          <label className="flex items-center gap-3 cursor-pointer">
                            <input 
                              type="checkbox"
                              checked={isWhatsappSame}
                              onChange={(e) => setIsWhatsappSame(e.target.checked)}
                              className="w-5 h-5 rounded-lg border-slate-300 text-green-600 focus:ring-green-500"
                            />
                            <span className="text-sm font-bold text-slate-600">Same as Phone</span>
                          </label>
                        )}
                      </div>

                      {formData.hasWhatsapp && !isWhatsappSame && (
                        <motion.div 
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="flex gap-2"
                        >
                          <div className="w-24 flex items-center justify-center bg-white rounded-xl text-xs font-bold text-slate-400 border border-slate-100">
                             {countryCode}
                          </div>
                          <input 
                            required
                            value={formData.whatsappNumber}
                            onChange={(e) => setFormData({...formData, whatsappNumber: e.target.value})}
                            placeholder="WhatsApp Number"
                            className="flex-1 px-6 py-4 bg-white border border-slate-100 rounded-2xl text-slate-800 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                          />
                        </motion.div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 ml-1">Home Address <span className="text-red-500">*</span></label>
                  <input 
                    required
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                    placeholder="Full residential address"
                    className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                  />
                </div>
              </section>

              {/* Clinical Header */}
              <section className="space-y-6">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Activity className="w-4 h-4" /> Clinical & Department Details
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Department <span className="text-red-500">*</span></label>
                    <select
                      value={formData.department}
                      onChange={(e) => setFormData({...formData, department: e.target.value as DepartmentType})}
                      className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 focus:ring-2 focus:ring-blue-500/20 transition-all font-bold appearance-none cursor-pointer"
                    >
                      <option value="Onco-urology">Onco-urology</option>
                      <option value="Andrology">Andrology</option>
                      <option value="Female urology">Female urology</option>
                      <option value="Pediatric urology">Pediatric urology</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Operation Status <span className="text-red-500">*</span></label>
                    <div className="flex gap-2 bg-slate-50 p-1 rounded-2xl">
                      {['Waiting', 'Scheduled'].map(s => (
                        <button
                          key={s}
                          type="button"
                          onClick={() => setFormData({...formData, operationStatus: s as any})}
                          className={cn(
                            "flex-1 py-3 rounded-xl text-sm font-bold transition-all",
                            formData.operationStatus === s ? "bg-white text-blue-600 shadow-sm" : "text-slate-400 hover:text-slate-600"
                          )}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Priority Level <span className="text-red-500">*</span></label>
                    <div className="flex gap-2 bg-slate-50 p-1 rounded-2xl">
                      {['Routine', 'Moderate', 'Urgent'].map(p => (
                        <button
                          key={p}
                          type="button"
                          onClick={() => setFormData({...formData, priorityLevel: p as any})}
                          className={cn(
                            "flex-1 py-3 rounded-xl text-sm font-bold transition-all",
                            formData.priorityLevel === p 
                              ? p === 'Urgent' ? "bg-red-600 text-white shadow-lg" : "bg-blue-600 text-white shadow-lg"
                              : "text-slate-400 hover:text-slate-600"
                          )}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                  </div>

                  {formData.operationStatus === 'Scheduled' && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="space-y-2 lg:col-span-3"
                    >
                      <label className="text-sm font-bold text-slate-700 ml-1">Scheduled Operation Date <span className="text-red-500">*</span></label>
                      <input 
                        type="date"
                        required
                        value={formData.scheduledDate}
                        onChange={(e) => setFormData({...formData, scheduledDate: e.target.value})}
                        className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 focus:ring-2 focus:ring-blue-500/20 transition-all font-bold"
                      />
                    </motion.div>
                  )}
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 ml-1">Clinical Diagnosis <span className="text-red-500">*</span></label>
                  <textarea 
                    required
                    value={formData.diagnosis}
                    onChange={(e) => setFormData({...formData, diagnosis: e.target.value})}
                    placeholder="Enter preliminary diagnosis and operation details..."
                    className="w-full px-6 py-4 bg-slate-50 border-none rounded-[2rem] text-slate-800 placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium min-h-[120px] resize-none"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Insurance Type <span className="text-red-500">*</span></label>
                    <select
                      value={formData.insuranceType}
                      onChange={(e) => setFormData({...formData, insuranceType: e.target.value as InsuranceType})}
                      className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 focus:ring-2 focus:ring-blue-500/20 transition-all font-bold appearance-none cursor-pointer"
                    >
                      <option value="State Funding">State Funding</option>
                      <option value="Health Insurance">Health Insurance</option>
                      <option value="Private">Private</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  {formData.insuranceType === 'Other' && (
                    <motion.div 
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="space-y-2"
                    >
                      <label className="text-sm font-bold text-slate-700 ml-1">Other Insurance Details</label>
                      <input 
                        value={formData.insuranceOtherDetails}
                        onChange={(e) => setFormData({...formData, insuranceOtherDetails: e.target.value})}
                        placeholder="Specify insurance provider..."
                        className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                      />
                    </motion.div>
                  )}
                </div>

                <div className="space-y-6 pt-6">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <FileText className="w-4 h-4" /> Medical Attachments & Links
                  </h3>
                  <div className="space-y-4">
                    {formData.attachments.map((att, i) => (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        key={i} 
                        className="p-6 bg-slate-50 rounded-3xl space-y-4 relative group"
                      >
                        <button 
                          type="button"
                          onClick={() => removeAttachment(i)}
                          className="absolute -top-2 -right-2 w-8 h-8 bg-white text-red-500 rounded-full shadow-md flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-4 h-4" />
                        </button>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Link Name</label>
                            <input 
                              value={att.name}
                              onChange={(e) => updateAttachment(i, 'name', e.target.value)}
                              placeholder="e.g., MRI Result Link"
                              className="w-full px-4 py-3 bg-white border-none rounded-xl text-sm font-bold text-slate-700"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">URL / Link</label>
                            <input 
                              value={att.url}
                              onChange={(e) => updateAttachment(i, 'url', e.target.value)}
                              placeholder="https://..."
                              className="w-full px-4 py-3 bg-white border-none rounded-xl text-sm font-bold text-blue-600"
                            />
                          </div>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Short Description</label>
                          <input 
                            value={att.description}
                            onChange={(e) => updateAttachment(i, 'description', e.target.value)}
                            placeholder="Optionally describe what this link contains..."
                            className="w-full px-4 py-3 bg-white border-none rounded-xl text-sm font-medium text-slate-500"
                          />
                        </div>
                      </motion.div>
                    ))}
                    <button 
                      type="button"
                      onClick={addAttachment}
                      className="w-full py-6 border-2 border-dashed border-slate-100 rounded-3xl text-slate-400 hover:text-blue-600 hover:border-blue-200 hover:bg-blue-50/30 transition-all font-bold flex items-center justify-center gap-3"
                    >
                      <Plus className="w-5 h-5" /> Add Medical Link or Attachment
                    </button>
                  </div>
                </div>
              </section>
            </form>

            <div className="p-8 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between shrink-0">
               <p className="text-xs text-slate-400 max-w-xs leading-relaxed italic">
                By adding this patient, you confirm that all medical triage protocols have been followed.
              </p>
              <div className="flex items-center gap-3">
                <button 
                  type="button"
                  onClick={onClose}
                  className="px-8 py-4 text-slate-500 font-bold hover:bg-slate-100 rounded-2xl transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleSubmit}
                  className="px-8 py-4 bg-blue-600 text-white font-bold rounded-2xl shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-2"
                >
                  {editPatient ? <Activity className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
                  {editPatient ? 'Update Patient Record' : 'Save Patient Record'}
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default AddPatientModal;
