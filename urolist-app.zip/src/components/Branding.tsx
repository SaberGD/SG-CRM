import React from 'react';
import { Facebook, MessageCircle, Phone, Info } from 'lucide-react';
import { useUI } from '../context/UIContext';
import { cn } from '../lib/utils';

interface BrandingProps {
  className?: string;
  variant?: 'large' | 'small' | 'minimal';
}

const Branding: React.FC<BrandingProps> = ({ className, variant = 'large' }) => {
  const { t } = useUI();
  
  const whatsappNumber = '+201024689480';
  const facebookUrl = 'https://www.facebook.com/MS.GD.FL/';

  if (variant === 'minimal') {
    return (
      <div className={cn("flex flex-col items-center gap-1", className)}>
        <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest opacity-70">
          {t('developedBy')}
        </p>
        <p className="text-[10px] font-black tracking-widest text-blue-600 dark:text-blue-400 uppercase">
          SABER GROUP &copy;
        </p>
        <div className="flex items-center gap-2 mt-0.5">
           <a href={`https://wa.me/${whatsappNumber}`} target="_blank" rel="noopener noreferrer" className="text-green-500 hover:scale-110 transition-transform">
            <MessageCircle className="w-3.5 h-3.5" />
          </a>
          <a href={facebookUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:scale-110 transition-transform">
            <Facebook className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("inline-flex flex-col items-center", className)}>
      <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest opacity-70">
        {t('developedBy')}
      </p>
      <div className="flex flex-col items-center gap-1.5 mt-1">
        <p className={cn(
          "font-black tracking-widest text-blue-600 dark:text-blue-400 uppercase",
          variant === 'large' ? "text-lg" : "text-sm"
        )}>
          SABER GROUP &copy;
        </p>
        
        <div className="flex items-center gap-3">
          <a 
            href={`https://wa.me/${whatsappNumber}`} 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-green-600 dark:text-green-400 hover:scale-110 transition-transform flex items-center gap-1.5"
            title="WhatsApp"
          >
            <MessageCircle className="w-5 h-5" />
          </a>
          <a 
            href={facebookUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-blue-600 dark:text-blue-400 hover:scale-110 transition-transform flex items-center gap-1.5"
            title="Facebook"
          >
            <Facebook className="w-5 h-5" />
          </a>
          <div className="w-[1px] h-3 bg-slate-200 dark:bg-slate-800" />
          <a 
            href={`https://wa.me/${whatsappNumber}`}
            className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-tight hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
          >
            Contact Us
          </a>
        </div>
        
        <p className="text-[9px] font-bold text-slate-300 dark:text-slate-700 uppercase tracking-tighter mt-1">
          &copy; {new Date().getFullYear()} All Rights Reserved
        </p>
      </div>
    </div>
  );
};

export default Branding;
