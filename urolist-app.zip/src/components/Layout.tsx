import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  UserPlus, 
  FileText, 
  Settings as SettingsIcon, 
  Activity, 
  LogOut,
  Menu,
  X,
  Stethoscope,
  HeartPulse,
  Baby,
  Venus,
  PlusCircle,
  Search,
  Moon,
  Sun,
  Globe,
  ArchiveRestore,
  ShieldCheck,
  ClipboardList as UrologyIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';
import { cn } from '../lib/utils';
import AddPatientModal from './AddPatientModal';
import Branding from './Branding';

const SidebarItem: React.FC<{
  to: string;
  icon: React.ElementType;
  label: string;
  active: boolean;
}> = ({ to, icon: Icon, label, active }) => (
  <Link
    to={to}
    className={cn(
      "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
      active 
        ? "bg-blue-600 text-white shadow-lg shadow-blue-200 dark:shadow-blue-900/20" 
        : "text-slate-600 dark:text-slate-400 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400"
    )}
  >
    <Icon className={cn("w-5 h-5", active ? "text-white" : "group-hover:text-blue-600 dark:group-hover:text-blue-400")} />
    <span className="font-medium text-sm">{label}</span>
  </Link>
);

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { profile, effectiveRole, impersonate, signOut } = useAuth();
  const { t, language, setLanguage, theme, setTheme } = useUI();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth >= 1024);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const isAdmin = profile?.role === 'admin';
  const isImpersonating = profile?.role === 'admin' && effectiveRole !== 'admin';

  // Role based visibility (using effectiveRole)
  const canAddPatient = effectiveRole === 'admin' || effectiveRole === 'doctor' || effectiveRole === 'coordinator';
  const canSeeAdminPanel = profile?.role === 'admin'; // Always show to real admin
  const canSeeStats = effectiveRole === 'admin' || effectiveRole === 'coordinator';

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      const isMobile = window.innerWidth < 1024;
      if (isMobile) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };
    
    // Set initial state
    handleResize();

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors duration-300">
      <AddPatientModal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} />
      
      {/* Mobile Backdrop */}
      <AnimatePresence>
        {isSidebarOpen && window.innerWidth < 1024 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-30 transition-all"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        initial={false}
        animate={{ 
          x: isSidebarOpen ? 0 : (language === 'ar' ? '105%' : '-105%'),
          width: 280
        }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className={cn(
          "fixed top-0 bottom-0 z-40 bg-white dark:bg-slate-900 border-r dark:border-slate-800 h-screen overflow-hidden flex flex-col shadow-2xl",
          language === 'ar' ? "right-0 border-l border-r-0" : "left-0",
          // On large screens, if it's open, it should be relative or push content
          window.innerWidth >= 1024 && isSidebarOpen ? "sticky" : "fixed"
        )}
      >
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200 dark:shadow-blue-900/20">
              <UrologyIcon className="text-white w-5 h-5" />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight dark:text-white">UroList</h1>
              <p className="text-[10px] uppercase font-bold tracking-widest text-slate-400">Manager Pro</p>
            </div>
          </Link>
          <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-8">
          {/* Main Menu */}
          <nav className="space-y-1">
            <p className="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">{t('mainMenu')}</p>
            <SidebarItem to="/" icon={LayoutDashboard} label={t('dashboard')} active={location.pathname === '/'} />
            <SidebarItem to="/archive" icon={ArchiveRestore} label="Archive" active={location.pathname === '/archive'} />
            <SidebarItem to="/reports" icon={FileText} label={t('reports')} active={location.pathname === '/reports'} />
            {profile?.role === 'admin' && (
              <SidebarItem to="/admin/permissions" icon={ShieldCheck} label="Permissions" active={location.pathname === '/admin/permissions'} />
            )}
          </nav>

          {/* Departments */}
          <nav className="space-y-1">
            <p className="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">{t('unitManagement')}</p>
            <SidebarItem to="/departments/all" icon={LayoutDashboard} label={t('allUnits')} active={location.pathname === '/departments/all'} />
            <SidebarItem to="/departments/onco-urology" icon={HeartPulse} label={t('onco')} active={location.pathname === '/departments/onco-urology'} />
            <SidebarItem to="/departments/andrology" icon={Activity} label={t('andro')} active={location.pathname === '/departments/andrology'} />
            <SidebarItem to="/departments/female-urology" icon={Venus} label={t('female')} active={location.pathname === '/departments/female-urology'} />
            <SidebarItem to="/departments/pediatric-urology" icon={Baby} label={t('pedia')} active={location.pathname === '/departments/pediatric-urology'} />
          </nav>

          {/* Administration */}
          {isAdmin && (
            <nav className="space-y-1">
              <p className="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">{t('adminPanel')}</p>
              <SidebarItem to="/admin/invitations" icon={UserPlus} label={t('invitations')} active={location.pathname === '/admin/invitations'} />
              <SidebarItem to="/admin/users" icon={Users} label={t('teamManagement')} active={location.pathname === '/admin/users'} />
              <SidebarItem to="/admin/logs" icon={Activity} label={t('logs')} active={location.pathname === '/admin/logs'} />
            </nav>
          )}

          {/* View As / Impersonation (Admin Only) */}
          {isAdmin && (
            <nav className="space-y-1">
              <p className="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">View As Role</p>
              <div className="px-2 space-y-1">
                {[
                  { role: 'admin', label: 'Administrator', icon: ShieldCheck },
                  { role: 'doctor', label: 'Doctor', icon: Stethoscope },
                  { role: 'nurse', label: 'Nurse', icon: HeartPulse },
                  { role: 'coordinator', label: 'Coordinator', icon: Users },
                ].map((r: any) => (
                  <button
                    key={r.role}
                    onClick={() => impersonate(r.role)}
                    className={cn(
                      "w-full flex items-center gap-3 px-4 py-2 rounded-xl transition-all text-sm font-medium",
                      effectiveRole === r.role 
                        ? "bg-amber-100 text-amber-700 shadow-sm border border-amber-200" 
                        : "text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800"
                    )}
                  >
                    <r.icon className={cn("w-4 h-4", effectiveRole === r.role ? "text-amber-600" : "text-slate-400")} />
                    {r.label}
                    {effectiveRole === r.role && <div className="ml-auto w-2 h-2 bg-amber-500 rounded-full animate-pulse" />}
                  </button>
                ))}
              </div>
            </nav>
          )}

          <nav className="space-y-1">
            <p className="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">{t('settings')}</p>
            <SidebarItem to="/settings" icon={SettingsIcon} label={t('settings')} active={location.pathname === '/settings'} />
          </nav>
        </div>

        {/* Branding & User Profile */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
          <Branding variant="minimal" />
          
          <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-slate-200 dark:bg-slate-700 rounded-full flex items-center justify-center font-bold text-slate-600 dark:text-slate-300 text-sm">
                {profile?.displayName?.charAt(0)}
              </div>
              <div>
                <p className="font-semibold text-sm text-slate-900 dark:text-white truncate max-w-[100px]">{profile?.displayName}</p>
                <p className="text-[10px] text-blue-600 dark:text-blue-400 font-bold uppercase tracking-tight">
                  {profile?.title || profile?.role}
                </p>
              </div>
            </div>
            <button 
              onClick={signOut}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-colors"
              title={t('signOut')}
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className={cn(
        "flex-1 flex flex-col h-screen overflow-hidden transition-all duration-300",
        isSidebarOpen && window.innerWidth >= 1024 
          ? (language === 'ar' ? "mr-0" : "ml-0") // Since it's sticky now, we don't need margin
          : ""
      )}>
        {/* Top Header */}
        <header className="h-20 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-6 shrink-0 z-20">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800 rounded-xl transition-all"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="h-6 w-[1px] bg-slate-200 dark:bg-slate-800 hidden sm:block" />
            <div>
              <h2 className="font-bold text-slate-800 dark:text-slate-200 hidden sm:block">
                {location.pathname === '/' ? t('overview') : 
                 location.pathname.startsWith('/departments') ? t('unitManagement') :
                 location.pathname.startsWith('/admin') ? t('adminPanel') : t('resourceCenter')}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center bg-slate-50 dark:bg-slate-800 p-1 rounded-xl border border-slate-100 dark:border-slate-700">
              <button 
                onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
                className="p-2 text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 flex items-center gap-2"
                title="Change Language"
              >
                <Globe className="w-5 h-5" />
                <span className="text-xs font-bold uppercase">{language === 'ar' ? 'EN' : 'AR'}</span>
              </button>
              <div className="w-[1px] h-4 bg-slate-200 dark:bg-slate-700 mx-1" />
              <button 
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="p-2 text-slate-600 dark:text-slate-400 hover:text-orange-500 dark:hover:text-yellow-400"
                title="Toggle Theme"
              >
                {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
            </div>

            <div className="h-6 w-[1px] bg-slate-200 dark:bg-slate-800 hidden md:block" />

            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder={t('search')} 
                className="pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border-none rounded-xl text-sm focus:ring-2 focus:ring-blue-500/20 w-48 lg:w-64 transition-all dark:text-white"
              />
            </div>
            
            {canAddPatient && (
              <button 
                onClick={() => setIsAddModalOpen(true)}
                className="p-2.5 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-200 dark:shadow-blue-900/30 hover:bg-blue-700 transition-all flex items-center gap-2"
              >
                <PlusCircle className="w-5 h-5" />
                <span className="text-sm font-bold pr-1 hidden sm:inline">{t('addPatient')}</span>
              </button>
            )}
          </div>
        </header>

        {/* Page Area */}
        <div className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-950 relative p-4 lg:p-8 transition-colors duration-300">
          <AnimatePresence>
            {isImpersonating && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="mb-6 bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <ShieldCheck className="w-5 h-5 text-amber-600" />
                  <p className="text-sm font-bold text-amber-800">
                    Viewing as <span className="uppercase">{effectiveRole}</span>. Some administrative actions are hidden.
                  </p>
                </div>
                <button 
                  onClick={() => impersonate(null)}
                  className="text-xs font-bold text-amber-600 hover:text-amber-700 bg-white px-3 py-1.5 rounded-lg border border-amber-200 shadow-sm transition-all"
                >
                  Reset View
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="max-w-7xl mx-auto"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
};

export default Layout;
