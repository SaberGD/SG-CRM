import React from 'react';
import { 
  Clock, 
  MapPin, 
  Phone, 
  ExternalLink, 
  MoreVertical,
  AlertCircle,
  Calendar,
  User,
  MessageCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Patient, PriorityLevel } from '../types';
import { formatDate, cn } from '../lib/utils';
import { motion } from 'motion/react';

const priorityColors: Record<PriorityLevel, string> = {
  Urgent: 'bg-red-50 text-red-600 border-red-100',
  Moderate: 'bg-orange-50 text-orange-600 border-orange-100',
  Routine: 'bg-blue-50 text-blue-600 border-blue-100'
};

const statusColors: Record<string, string> = {
  Waiting: 'bg-slate-100 text-slate-600',
  Scheduled: 'bg-purple-100 text-purple-600',
  Operated: 'bg-green-100 text-green-600',
  Cancelled: 'bg-red-100 text-red-600'
};

const PatientCard: React.FC<{ patient: Patient }> = ({ patient }) => {
  return (
    <motion.div 
      whileHover={{ y: -4 }}
      className="bg-white rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-slate-200/50 transition-all p-6 group h-full flex flex-col"
    >
      <div className="flex items-start justify-between mb-4">
        <div className={cn(
          "px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-widest border",
          priorityColors[patient.priorityLevel]
        )}>
          {patient.priorityLevel}
        </div>
        <div className="flex items-center gap-2">
          <button className="text-slate-400 hover:text-slate-600 transition-colors">
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      <Link to={`/patients/${patient.id}`} className="flex-1">
        <h4 className="text-lg font-extrabold text-slate-900 group-hover:text-blue-600 transition-colors leading-tight mb-1">
          {patient.fullName}
        </h4>
        <p className="text-sm text-slate-500 font-medium line-clamp-1 mb-4">{patient.diagnosis}</p>

        <div className="space-y-2 mb-6 text-sm text-slate-600">
          <div className="flex items-center gap-3">
            <User className="w-4 h-4 text-slate-400" />
            <span className="font-semibold">{patient.age}y • {patient.gender}</span>
          </div>
          <div className="flex items-center gap-3">
            <Clock className="w-4 h-4 text-slate-400" />
            <span className="font-semibold">Added {formatDate(patient.createdAt)}</span>
          </div>
          {patient.scheduledDate && (
            <div className="flex items-center gap-3 text-purple-600 font-bold">
              <Calendar className="w-4 h-4" />
              <span>Op: {formatDate(patient.scheduledDate)}</span>
            </div>
          )}
        </div>
      </Link>

      <div className="pt-6 border-t border-slate-100 flex items-center justify-between mt-auto">
        <div className={cn(
          "px-3 py-1 rounded-xl text-[10px] font-bold uppercase tracking-tight",
          statusColors[patient.operationStatus]
        )}>
          {patient.operationStatus}
        </div>
        
        <div className="flex items-center gap-2">
          {patient.hasWhatsapp && (
            <a 
              href={`https://wa.me/${(patient.whatsappNumber || patient.phoneNumber).replace(/\D/g, '')}`} 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 bg-green-50 text-green-600 hover:bg-green-100 rounded-xl transition-all"
              title="WhatsApp Contact"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
            </a>
          )}
          <Link 
            to={`/patients/${patient.id}`}
            className="p-2 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-xl transition-all"
          >
            <ExternalLink className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </motion.div>
  );
};

export default PatientCard;
