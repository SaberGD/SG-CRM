import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, loginWithGoogle, logout } from '../lib/firebase';
import { UserProfile, Invitation } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  effectiveRole: UserProfile['role'] | null;
  loading: boolean;
  error: string | null;
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
  isAuthorized: boolean;
  impersonate: (role: UserProfile['role'] | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [impersonatedRole, setImpersonatedRole] = useState<UserProfile['role'] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAuthorized, setIsAuthorized] = useState(false);

  const effectiveRole = impersonatedRole || profile?.role || null;

  const impersonate = (role: UserProfile['role'] | null) => {
    if (profile?.role === 'admin') {
      setImpersonatedRole(role);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setLoading(true);
      setError(null);
      
      if (firebaseUser) {
        try {
          // Check invitation first
          const BOOTSTRAP_ADMIN = 'saber.gd.fl@gmail.com';
          const isBootstrapAdmin = firebaseUser.email === BOOTSTRAP_ADMIN;
          
          let hasPendingInvitation = false;
          let invitation: any = null;

          if (!isBootstrapAdmin) {
            const invitationRef = doc(db, 'invitations', firebaseUser.email!);
            try {
              const invitationSnap = await getDoc(invitationRef);
              hasPendingInvitation = invitationSnap.exists() && invitationSnap.data()?.status === 'pending';
              invitation = invitationSnap.data();
            } catch (err) {
              console.warn('Error fetching invitation (might be expected for new users):', err);
            }
          }

          const profileRef = doc(db, 'users', firebaseUser.uid);
          let profileSnap;
          try {
            profileSnap = await getDoc(profileRef);
          } catch (err) {
            throw handleFirestoreError(err, OperationType.GET, `users/${firebaseUser.uid}`);
          }
          
          if (profileSnap.exists()) {
            setProfile(profileSnap.data() as UserProfile);
            setIsAuthorized(true);
          } else if (isBootstrapAdmin || hasPendingInvitation) {
            // First time login with valid invitation OR bootstrap admin
            const newProfile: UserProfile = {
              uid: firebaseUser.uid,
              email: firebaseUser.email!,
              displayName: isBootstrapAdmin ? (firebaseUser.displayName || 'Admin') : (invitation?.name || firebaseUser.displayName || 'User'),
              title: isBootstrapAdmin ? 'System Administrator' : (invitation?.title || ''),
              role: isBootstrapAdmin ? 'admin' : (invitation?.role || 'doctor'),
              active: true,
              createdAt: new Date().toISOString(),
              lastLogin: new Date().toISOString(),
            };
            
            try {
              await setDoc(profileRef, newProfile);
            } catch (err) {
              throw handleFirestoreError(err, OperationType.WRITE, `users/${firebaseUser.uid}`);
            }
            
            // Update invitation status if it existed
            if (hasPendingInvitation && firebaseUser.email) {
              try {
                const invitationRef = doc(db, 'invitations', firebaseUser.email);
                await setDoc(invitationRef, { status: 'accepted' }, { merge: true });
              } catch (err) {
                console.warn('Failed to update invitation status:', err);
              }
            }
            
            setProfile(newProfile);
            setIsAuthorized(true);
          } else {
            setIsAuthorized(false);
            setError('Access Denied: You have not been invited to this system.');
            setUser(firebaseUser);
            setLoading(false);
            return;
          }
          
          setUser(firebaseUser);
        } catch (err) {
          console.error('Auth error:', err);
          setError('An error occurred during authentication.');
        }
      } else {
        setUser(null);
        setProfile(null);
        setIsAuthorized(false);
      }
      
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signIn = async () => {
    try {
      await loginWithGoogle();
    } catch (err) {
      console.error('Sign in error:', err);
      if (err instanceof Error) {
        if (err.message.includes('auth/unauthorized-domain')) {
          setError(`Domain not authorized. Please add the current domain to your Firebase Console (Authentication > Settings > Authorized domains).`);
        } else {
          setError(err.message);
        }
      } else {
        setError('Failed to sign in with Google.');
      }
    }
  };

  const handleSignOut = async () => {
    try {
      await logout();
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      profile, 
      effectiveRole,
      loading, 
      error, 
      signIn, 
      signOut: handleSignOut, 
      isAuthorized,
      impersonate
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
