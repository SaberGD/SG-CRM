import React, { createContext, useContext, useEffect, useState } from 'react';

type Language = 'en' | 'ar';
type Theme = 'light' | 'dark';

interface UIContextType {
  language: Language;
  theme: Theme;
  setLanguage: (lang: Language) => void;
  setTheme: (theme: Theme) => void;
  t: (key: string) => string;
}

const UIContext = createContext<UIContextType | undefined>(undefined);

const translations: Record<Language, Record<string, string>> = {
  en: {
    dashboard: 'Dashboard',
    reports: 'Reports',
    settings: 'Settings',
    onco: 'Onco-urology',
    andro: 'Andrology',
    female: 'Female Urology',
    pedia: 'Pediatric Urology',
    addPatient: 'Add Patient',
    search: 'Search patient, ID...',
    signOut: 'Sign Out',
    developedBy: 'Developed by Saber Group',
    totalPatients: 'Total Patients',
    waitingList: 'Waiting List',
    scheduled: 'Scheduled',
    operated: 'Operated',
    loginTitle: 'UroList',
    loginSub: 'Surgical Waiting List Management System',
    continueGoogle: 'Continue with Google',
    accessDenied: 'Access Denied',
    backToLogin: 'Back to Login',
    teamManagement: 'Team Management',
    invitations: 'Invitations',
    logs: 'Activity Logs',
    adminPanel: 'Admin Panel',
    overview: 'Hospital Overview',
    unitManagement: 'Unit Management',
    allUnits: 'All Units',
    dateFrom: 'Date From',
    dateTo: 'Date To',
    filterByDate: 'Filter by Date',
    statusSummary: 'Status Summary'
  },
  ar: {
    dashboard: 'لوحة التحكم',
    reports: 'التقارير',
    settings: 'الإعدادات',
    onco: 'أورام المسالك',
    andro: 'أمراض الذكورة',
    female: 'المسالك النسائية',
    pedia: 'مسالك الأطفال',
    addPatient: 'إضافة مريض',
    search: 'ابحث عن مريض، رقم هوية...',
    signOut: 'تسجيل الخروج',
    developedBy: 'تطوير مجموعة صابر',
    totalPatients: 'إجمالي المرضى',
    waitingList: 'قائمة الانتظار',
    scheduled: 'العمليات المجدولة',
    operated: 'تمت العملية',
    loginTitle: 'UroList',
    loginSub: 'نظام إدارة قوائم العمليات الجراحية',
    continueGoogle: 'المتابعة عبر جوجل',
    accessDenied: 'تم رفض الدخول',
    backToLogin: 'العودة لتسجيل الدخول',
    teamManagement: 'إدارة الفريق',
    invitations: 'الدعوات',
    logs: 'سجل النشاطات',
    adminPanel: 'لوحة المسؤول',
    overview: 'نظرة عامة',
    unitManagement: 'إدارة الوحدة',
    allUnits: 'كل الوحدات',
    dateFrom: 'من تاريخ',
    dateTo: 'إلى تاريخ',
    filterByDate: 'تصفية حسب التاريخ',
    statusSummary: 'ملخص الحالات'
  }
};

export const UIProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(
    (localStorage.getItem('lang') as Language) || 'en'
  );
  const [theme, setTheme] = useState<Theme>(
    (localStorage.getItem('theme') as Theme) || 'light'
  );

  useEffect(() => {
    localStorage.setItem('lang', language);
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    localStorage.setItem('theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const t = (key: string) => translations[language][key] || key;

  return (
    <UIContext.Provider value={{ language, theme, setLanguage, setTheme, t }}>
      {children}
    </UIContext.Provider>
  );
};

export const useUI = () => {
  const context = useContext(UIContext);
  if (!context) throw new Error('useUI must be used within UIProvider');
  return context;
};
