import { collection, getDocs, writeBatch, doc, deleteDoc, Timestamp } from 'firebase/firestore';
import { db } from './firebase';
import toast from 'react-hot-toast';

const COLLECTIONS = ['patients', 'invitations', 'users', 'activityLogs'];

export const exportSystemData = async () => {
  const loadingToast = toast.loading('Exporting system data...');
  try {
    const backupData: Record<string, any[]> = {};

    for (const colName of COLLECTIONS) {
      const snap = await getDocs(collection(db, colName));
      backupData[colName] = snap.docs.map(d => ({
        id: d.id,
        ...d.data()
      }));
    }

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const timestamp = new Date().toISOString().split('T')[0];
    
    link.href = url;
    link.download = `urolist_backup_${timestamp}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success('Backup downloaded successfully', { id: loadingToast });
  } catch (error) {
    console.error('Export failed:', error);
    toast.error('Failed to export data', { id: loadingToast });
  }
};

export const importSystemData = async (file: File) => {
  const loadingToast = toast.loading('Restoring system data...');
  try {
    const text = await file.text();
    const data = JSON.parse(text);

    if (!data.patients || !data.users) {
      throw new Error('Invalid backup file format');
    }

    const batch = writeBatch(db);

    // This is a simplified restore - it merges data. 
    // For a full clear-and-restore, we'd need to delete existing first.
    // Given the request, we will overwrite/add.

    for (const colName of COLLECTIONS) {
      if (data[colName]) {
        for (const item of data[colName]) {
          const { id, ...rest } = item;
          const ref = doc(db, colName, id);
          batch.set(ref, rest);
        }
      }
    }

    await batch.commit();
    toast.success('System restored successfully!', { id: loadingToast });
    setTimeout(() => window.location.reload(), 1500);
  } catch (error) {
    console.error('Import failed:', error);
    toast.error('Failed to restore data. Check file format.', { id: loadingToast });
  }
};
