import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyBGwv3BiCiz8QLj2QfVlnRlgZnHNBq0KRQ",
  authDomain: "urology-waiting-list.firebaseapp.com",
  projectId: "urology-waiting-list",
  storageBucket: "urology-waiting-list.firebasestorage.app",
  messagingSenderId: "1080610136419",
  appId: "1:1080610136419:web:fe883515feba080f587356",
  measurementId: "G-FF9LTKRB61"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();

export const loginWithGoogle = () => signInWithPopup(auth, googleProvider);
export const logout = () => signOut(auth);
