import { db } from './firebase';
import { collection, addDoc, setDoc, doc, serverTimestamp } from 'firebase/firestore';

export const seedDatabase = async () => {
  try {
    // 1. Create default labels
    const labels = [
      { name: 'Emergency', color: '#ef4444' },
      { name: 'Cancer', color: '#9333ea' },
      { name: 'Follow-up', color: '#3b82f6' },
      { name: 'Needs ICU', color: '#f59e0b' },
      { name: 'Financial Issue', color: '#10b981' },
    ];

    for (const label of labels) {
      await addDoc(collection(db, 'labels'), label);
    }

    // 2. Create some invitations (one for the user email if provided)
    const invitations = [
      { email: 'saber.gd.fl@gmail.com', role: 'admin', status: 'pending', invitedBy: 'System', createdAt: new Date().toISOString() },
      { email: 'admin@hospital.com', role: 'admin', status: 'pending', invitedBy: 'System', createdAt: new Date().toISOString() },
      { email: 'doctor@hospital.com', role: 'doctor', status: 'pending', invitedBy: 'System', createdAt: new Date().toISOString() },
      { email: 'nurse@hospital.com', role: 'nurse', status: 'pending', invitedBy: 'System', createdAt: new Date().toISOString() },
    ];

    for (const inv of invitations) {
      await setDoc(doc(db, 'invitations', inv.email), inv);
    }

    // 3. Create sample patients
    const patients = [
      {
        fullName: 'Robert Wilson',
        age: 64,
        gender: 'Male',
        address: '123 Medical Way, City',
        phoneNumber: '+1555123456',
        nationalId: 'ID-987654',
        department: 'Onco-urology',
        diagnosis: 'Renal Cell Carcinoma - Stage II - Scheduled for Partial Nephrectomy',
        insuranceType: 'Health Insurance',
        priorityLevel: 'Urgent',
        operationStatus: 'Waiting',
        createdBy: 'system',
        labels: ['Cancer', 'Needs ICU'],
        attachments: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      },
      {
        fullName: 'Elena Rodriguez',
        age: 42,
        gender: 'Female',
        address: '45 Sunshine Blvd, West Side',
        phoneNumber: '+1555987654',
        nationalId: 'ID-123456',
        department: 'Female urology',
        diagnosis: 'Severe Stress Urinary Incontinence - Sling Procedure',
        insuranceType: 'Private',
        priorityLevel: 'Moderate',
        operationStatus: 'Scheduled',
        scheduledDate: new Date(Date.now() + 86400000 * 5),
        createdBy: 'system',
        labels: ['Follow-up'],
        attachments: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      }
    ];

    for (const patient of patients) {
      await addDoc(collection(db, 'patients'), patient);
    }

    console.log('Database seeded successfully!');
    return true;
  } catch (error) {
    console.error('Seeding failed:', error);
    return false;
  }
};
