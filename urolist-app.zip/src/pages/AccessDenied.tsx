import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Link, Navigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { ShieldAlert, LogOut, ArrowLeft } from 'lucide-react';

const AccessDenied: React.FC = () => {
  const { user, isAuthorized, signOut, loading, error } = useAuth();

  if (!loading && user && isAuthorized) {
    return <Navigate to="/" />;
  }

  if (!loading && !user) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="max-w-md w-full bg-white rounded-[2.5rem] shadow-2xl shadow-slate-200/50 p-12 text-center border border-slate-100"
      >
        <div className="w-24 h-24 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center animate-pulse">
            <ShieldAlert className="text-red-600 w-8 h-8" />
          </div>
        </div>
        
        <h1 className="text-3xl font-extrabold text-slate-900 mb-4">Access Denied</h1>
        <p className="text-slate-500 font-medium mb-10 leading-relaxed">
          {error || `Your account (${user?.email}) has not been authorized to access this system. Please contact the department administrator to request an invitation.`}
        </p>

        <div className="space-y-4">
          <button
            onClick={signOut}
            className="w-full flex items-center justify-center gap-3 bg-red-600 text-white font-bold py-4 px-6 rounded-2xl hover:bg-red-700 transition-all shadow-lg shadow-red-100"
          >
            <LogOut className="w-5 h-5" />
            Sign Out
          </button>
          
          <Link
            to="/login"
            className="w-full flex items-center justify-center gap-3 bg-slate-50 text-slate-600 font-bold py-4 px-6 rounded-2xl hover:bg-slate-100 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Login
          </Link>
        </div>

        <p className="mt-12 text-[10px] text-slate-400 font-bold uppercase tracking-widest">
          Security Incident ID: {Math.random().toString(36).substr(2, 9).toUpperCase()}
        </p>
      </motion.div>
    </div>
  );
};

export default AccessDenied;
