import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, 
  Calendar, 
  AlertCircle,
  ArchiveRestore,
  X,
  History,
  UserCheck
} from 'lucide-react';
import { collection, query, where, onSnapshot, orderBy, doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Patient } from '../types';
import { useUI } from '../context/UIContext';
import { useAuth } from '../context/AuthContext';
import { formatDate } from '../lib/utils';
import { motion } from 'motion/react';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';
import toast from 'react-hot-toast';

const ArchiveView: React.FC = () => {
  const { t } = useUI();
  const { effectiveRole } = useAuth();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    setLoading(true);
    const q = query(
      collection(db, 'patients'), 
      where('operationStatus', '==', 'Cancelled'),
      orderBy('updatedAt', 'desc')
    );

    const unsub = onSnapshot(q, (snap) => {
      setPatients(snap.docs.map(d => ({ id: d.id, ...d.data() } as Patient)));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'patients');
      setLoading(false);
    });

    return () => unsub();
  }, []);

  const handleRestore = async (e: React.MouseEvent, patientId: string, name: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!window.confirm(`Restore ${name} to the waiting list?`)) return;

    const loadingToast = toast.loading("Restoring patient...");
    try {
      await updateDoc(doc(db, 'patients', patientId), {
        operationStatus: 'Waiting',
        updatedAt: serverTimestamp()
      });
      toast.success("Patient restored successfully", { id: loadingToast });
    } catch (err) {
      toast.error("Failed to restore patient", { id: loadingToast });
    }
  };

  const filteredPatients = patients.filter(p => 
    p.fullName.toLowerCase().includes(search.toLowerCase()) || 
    p.nationalId.includes(search)
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500" />
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-20">
      <div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-3">
          <ArchiveRestore className="w-8 h-8 text-red-500" /> Patient Archive
        </h1>
        <p className="text-slate-500 dark:text-slate-400 font-medium mt-1">
          Cancelled or withdrawn patient records. You can restore them to the waiting list at any time.
        </p>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          placeholder="Search by name or national ID..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-12 pr-6 py-4 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[2rem] shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all dark:text-white"
        />
        {search && (
          <button 
            onClick={() => setSearch('')}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-2 text-slate-400 hover:text-slate-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {filteredPatients.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPatients.map((patient) => (
            <Link
              key={patient.id}
              to={`/patients/${patient.id}`}
            >
              <motion.div 
                whileHover={{ y: -4 }}
                className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all relative group"
              >
                <div className="flex justify-between items-start mb-4">
                  <div className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-red-50 text-red-600 dark:bg-red-950/30 dark:text-red-400">
                    Cancelled
                  </div>
                  {(effectiveRole === 'admin' || effectiveRole === 'coordinator') && (
                    <button 
                      onClick={(e) => handleRestore(e, patient.id!, patient.fullName)}
                      className="p-2 bg-blue-50 text-blue-600 rounded-xl opacity-0 group-hover:opacity-100 transition-all hover:bg-blue-100 flex items-center gap-2 text-[10px] font-bold px-3"
                    >
                      <History className="w-3.5 h-3.5" /> Restore
                    </button>
                  )}
                </div>
                
                <h4 className="font-extrabold text-slate-900 dark:text-white text-lg mb-2 truncate">{patient.fullName}</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-4 h-8">{patient.diagnosis}</p>
                
                <div className="pt-4 border-t border-slate-50 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-slate-400">
                    <Calendar className="w-3.5 h-3.5" />
                    <span className="text-[10px] font-bold">
                      Cancelled {formatDate(patient.updatedAt)}
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest">{patient.department}</span>
                </div>
              </motion.div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 p-12 text-center transition-colors">
          <div className="w-20 h-20 bg-slate-50 dark:bg-slate-800 rounded-3xl flex items-center justify-center mx-auto mb-6">
            <ArchiveRestore className="w-10 h-10 text-slate-300 dark:text-slate-700" />
          </div>
          <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-2">Archive is empty</h3>
          <p className="text-slate-500 dark:text-slate-400 max-w-sm mx-auto">No cancelled patient records found.</p>
        </div>
      )}
    </div>
  );
};

export default ArchiveView;
