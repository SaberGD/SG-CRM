import React, { useEffect, useState } from 'react';
import { 
  Users, 
  Clock, 
  CheckCircle2, 
  Calendar, 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight,
  ClipboardList,
  FileText
} from 'lucide-react';
import { motion } from 'motion/react';
import { collection, query, where, getDocs, limit, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useUI } from '../context/UIContext';
import { useAuth } from '../context/AuthContext';
import { Patient, ActivityLog } from '../types';
import { formatDate, formatDateTime, cn } from '../lib/utils';
import Branding from '../components/Branding';

const StatCard: React.FC<{
  title: string;
  value: string | number;
  icon: React.ElementType;
  color: string;
}> = ({ title, value, icon: Icon, color }) => (
  <motion.div 
    whileHover={{ y: -4 }}
    className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl hover:shadow-slate-200/50 dark:hover:shadow-none transition-all cursor-default"
  >
    <div className="flex items-center justify-between mb-4">
      <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center", color)}>
        <Icon className="w-6 h-6" />
      </div>
    </div>
    <h3 className="text-slate-500 dark:text-slate-400 font-medium text-sm mb-1">{title}</h3>
    <p className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">{value}</p>
  </motion.div>
);

const Dashboard: React.FC = () => {
  const { t } = useUI();
  const { effectiveRole } = useAuth();
  const [stats, setStats] = useState({
    total: 0,
    waiting: 0,
    operated: 0,
    scheduled: 0
  });
  const [recentLogs, setRecentLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const patientsSnap = await getDocs(collection(db, 'patients'));
        const patients = patientsSnap.docs.map(d => d.data() as Patient);
        
        const deptStats = {
          onco: patients.filter(p => p.department === 'Onco-urology').length,
          andro: patients.filter(p => p.department === 'Andrology').length,
          female: patients.filter(p => p.department === 'Female urology').length,
          pedia: patients.filter(p => p.department === 'Pediatric urology').length,
        };

        setStats({
          total: patients.length,
          waiting: patients.filter(p => p.operationStatus === 'Waiting').length,
          operated: patients.filter(p => p.operationStatus === 'Operated').length,
          scheduled: patients.filter(p => p.operationStatus === 'Scheduled').length,
          ...deptStats
        });

        const logsQuery = query(collection(db, 'activityLogs'), orderBy('timestamp', 'desc'), limit(10));
        const logsSnap = await getDocs(logsQuery);
        setRecentLogs(logsSnap.docs.map(d => ({ id: d.id, ...d.data() } as ActivityLog)));
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500" />
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-12">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">{t('overview')}</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium mt-1">Real-time status of the surgical waiting lists.</p>
        </div>
        <div className="flex items-center gap-2 bg-white dark:bg-slate-900 px-4 py-2 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm text-sm font-bold text-slate-600 dark:text-slate-400">
          <Calendar className="w-4 h-4 text-blue-500" />
          {formatDate(new Date())}
        </div>
      </div>

      {/* Grid Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title={t('totalPatients')} 
          value={stats.total} 
          icon={Users} 
          color="bg-blue-50 dark:bg-blue-950/30 text-blue-600 dark:text-blue-400" 
        />
        <StatCard 
          title={t('waitingList')} 
          value={stats.waiting} 
          icon={Clock} 
          color="bg-orange-50 dark:bg-orange-950/30 text-orange-600 dark:text-orange-400" 
        />
        <StatCard 
          title={t('scheduled')} 
          value={stats.scheduled} 
          icon={Calendar} 
          color="bg-purple-50 dark:bg-purple-950/30 text-purple-600 dark:text-purple-400" 
        />
        <StatCard 
          title={t('operated')} 
          value={stats.operated} 
          icon={CheckCircle2} 
          color="bg-green-50 dark:bg-green-950/30 text-green-600 dark:text-green-400" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <div className="lg:col-span-2 space-y-6">
          {(effectiveRole === 'admin' || effectiveRole === 'coordinator') ? (
            <div className="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm p-8 h-full transition-colors duration-300">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-slate-600 dark:text-slate-400" />
                  </div>
                  <h3 className="font-extrabold text-slate-900 dark:text-white text-lg">{t('logs')}</h3>
                </div>
                <button className="text-sm font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 transition-colors">
                  View Full Log
                </button>
              </div>

              <div className="space-y-6">
                {recentLogs.length > 0 ? recentLogs.map((log, idx) => (
                  <div key={log.id} className="flex gap-4 relative">
                    {idx !== recentLogs.length - 1 && (
                      <div className="absolute left-5 top-10 w-[2px] h-10 bg-slate-50 dark:bg-slate-800" />
                    )}
                    <div className="w-10 h-10 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center shrink-0 border-2 border-white dark:border-slate-900 shadow-sm">
                      <div className="w-2 h-2 bg-blue-500 rounded-full" />
                    </div>
                    <div className="flex-1 pb-4">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <p className="font-bold text-slate-900 dark:text-white">{log.userName}</p>
                          <span className="text-[9px] bg-slate-100 dark:bg-slate-800 text-slate-500 px-1.5 py-0.5 rounded font-bold uppercase">{log.userRole}</span>
                        </div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{formatDateTime(log.timestamp)}</span>
                      </div>
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        <span className="font-bold text-slate-700 dark:text-slate-300">{log.action}</span>
                        {log.patientName && ` for patient `}
                        {log.patientName && <span className="font-bold text-blue-600 dark:text-blue-400">{log.patientName}</span>}
                      </p>
                    </div>
                  </div>
                )) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
                      <ClipboardList className="w-8 h-8 text-slate-300 dark:text-slate-600" />
                    </div>
                    <p className="text-slate-400 font-medium">No recent activity detected.</p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm p-12 text-center flex flex-col items-center justify-center h-full min-h-[300px]">
              <div className="w-20 h-20 bg-blue-50 dark:bg-blue-900/20 rounded-[2rem] flex items-center justify-center mb-6">
                <Users className="w-10 h-10 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white mb-3">Welcome to UroList</h3>
              <p className="text-slate-500 dark:text-slate-400 max-w-sm">
                Select a department from the sidebar to view current surgical waiting lists and patient details.
              </p>
            </div>
          )}
        </div>

        {/* Right Stats Sidebar */}
        <div className="space-y-6">
          {(effectiveRole === 'admin' || effectiveRole === 'coordinator') && (
            <div className="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm p-8">
              <h3 className="font-extrabold text-slate-900 dark:text-white text-lg mb-6">Unit Statistics</h3>
              <div className="space-y-4">
                {[
                  { label: t('onco'), count: (stats as any).onco || 0, color: 'bg-blue-500', bg: 'bg-blue-50 dark:bg-blue-950/20' },
                  { label: t('andro'), count: (stats as any).andro || 0, color: 'bg-indigo-500', bg: 'bg-indigo-50 dark:bg-indigo-950/20' },
                  { label: t('female'), count: (stats as any).female || 0, color: 'bg-pink-500', bg: 'bg-pink-50 dark:bg-pink-950/20' },
                  { label: t('pedia'), count: (stats as any).pedia || 0, color: 'bg-amber-500', bg: 'bg-amber-50 dark:bg-amber-950/20' }
                ].map((item) => (
                  <div key={item.label} className={cn("p-4 rounded-2xl flex items-center justify-between", item.bg)}>
                    <div className="flex items-center gap-3">
                      <div className={cn("w-3 h-3 rounded-full", item.color)} />
                      <span className="font-bold text-slate-700 dark:text-slate-300 text-sm tracking-tight">{item.label}</span>
                    </div>
                    <span className="font-extrabold text-slate-900 dark:text-white">{item.count}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm p-8">
            <h3 className="font-extrabold text-slate-900 dark:text-white text-lg mb-6">Priority Distribution</h3>
            <div className="space-y-4">
              {[
                { label: 'Urgent', count: stats.waiting, color: 'bg-red-500', bg: 'bg-red-50 dark:bg-red-950/20' },
                { label: 'Moderate', count: stats.scheduled, color: 'bg-orange-500', bg: 'bg-orange-50 dark:bg-orange-950/20' },
                { label: 'Routine', count: stats.operated, color: 'bg-blue-500', bg: 'bg-blue-50 dark:bg-blue-950/20' }
              ].map((item) => (
                <div key={item.label} className={cn("p-4 rounded-2xl flex items-center justify-between", item.bg)}>
                  <div className="flex items-center gap-3">
                    <div className={cn("w-3 h-3 rounded-full", item.color)} />
                    <span className="font-bold text-slate-700 dark:text-slate-300 text-sm tracking-tight">{item.label}</span>
                  </div>
                  <span className="font-extrabold text-slate-900 dark:text-white">{item.count}</span>
                </div>
              ))}
            </div>
          </div>

          {(effectiveRole === 'admin' || effectiveRole === 'coordinator') && (
            <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-[2rem] p-8 text-white shadow-xl shadow-blue-200 dark:shadow-none">
              <h3 className="font-bold text-xl mb-2">{t('reports')}</h3>
              <p className="text-blue-100 text-sm mb-6 leading-relaxed opacity-80">
                Download the current waiting list statistics in Excel or PDF format.
              </p>
              <button className="w-full bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold py-3 px-6 rounded-2xl transition-all flex items-center justify-center gap-2 backdrop-blur-sm">
                <FileText className="w-5 h-5" />
                Download Center
              </button>
            </div>
          )}
          
          <div className="text-center p-4">
            <Branding variant="small" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
