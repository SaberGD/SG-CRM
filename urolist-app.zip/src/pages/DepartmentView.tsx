import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Search, 
  Filter, 
  Calendar, 
  ChevronRight, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  CalendarDays,
  FileText,
  X
} from 'lucide-react';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Patient } from '../types';
import { useUI } from '../context/UIContext';
import { cn, formatDate } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';

const DepartmentView: React.FC = () => {
  const { dept } = useParams<{ dept: string }>();
  const { t, language } = useUI();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  
  // Date Filters
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const getDeptTitle = (d: string) => {
    switch (d) {
      case 'onco-urology': return t('onco');
      case 'andrology': return t('andro');
      case 'female-urology': return t('female');
      case 'pediatric-urology': return t('pedia');
      case 'all': return t('allUnits');
      default: return d;
    }
  };

  useEffect(() => {
    setLoading(true);
    let q = query(collection(db, 'patients'), orderBy('createdAt', 'desc'));
    
    if (dept && dept !== 'all') {
      let deptName = '';
      switch(dept) {
        case 'onco-urology': deptName = 'Onco-urology'; break;
        case 'andrology': deptName = 'Andrology'; break;
        case 'female-urology': deptName = 'Female urology'; break;
        case 'pediatric-urology': deptName = 'Pediatric urology'; break;
        default: deptName = dept;
      }
      q = query(collection(db, 'patients'), where('department', '==', deptName), orderBy('createdAt', 'desc'));
    }

    const unsub = onSnapshot(q, (snap) => {
      setPatients(snap.docs.map(d => ({ id: d.id, ...d.data() } as Patient)));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'patients');
      setLoading(false);
    });

    return () => unsub();
  }, [dept]);

  const filteredPatients = patients.filter(p => {
    const matchesSearch = 
      p.fullName.toLowerCase().includes(search.toLowerCase()) || 
      p.nationalId.includes(search);
    
    // Determine relevant date based on status or general view
    const pDate = p.scheduledDate || p.completedAt || p.createdAt;
    const patientDate = pDate ? (pDate.toDate ? pDate.toDate() : new Date(pDate)) : null;
    let matchesDate = true;

    if (startDate || endDate) {
      if (!patientDate) {
        matchesDate = false;
      } else {
        const start = startDate ? new Date(startDate) : new Date('1900-01-01');
        const end = endDate ? new Date(endDate) : new Date('2100-12-31');
        start.setHours(0, 0, 0, 0);
        end.setHours(23, 59, 59, 999);
        matchesDate = patientDate >= start && patientDate <= end;
      }
    }

    return matchesSearch && matchesDate;
  });

  const stats = {
    waiting: filteredPatients.filter(p => p.operationStatus === 'Waiting').length,
    scheduled: filteredPatients.filter(p => p.operationStatus === 'Scheduled').length,
    operated: filteredPatients.filter(p => p.operationStatus === 'Operated').length,
  };

  const groupedPatients = {
    Waiting: filteredPatients.filter(p => p.operationStatus === 'Waiting'),
    Scheduled: filteredPatients.filter(p => p.operationStatus === 'Scheduled'),
    Operated: filteredPatients.filter(p => p.operationStatus === 'Operated'),
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500" />
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {getDeptTitle(dept || '') || 'Department'}
          </h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium mt-1">
            {dept === 'all' ? 'Comprehensive view of all departments.' : 'Unit-specific surgical waiting list.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 p-1 shadow-sm">
            <div className="px-3 py-2 flex flex-col">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('dateFrom')}</span>
              <input 
                type="date" 
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="text-xs font-bold border-none bg-transparent p-0 focus:ring-0 dark:text-white dark:color-scheme-dark" 
              />
            </div>
            <div className="w-[1px] h-8 bg-slate-100 dark:bg-slate-800 mx-1" />
            <div className="px-3 py-2 flex flex-col">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('dateTo')}</span>
              <input 
                type="date" 
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="text-xs font-bold border-none bg-transparent p-0 focus:ring-0 dark:text-white dark:color-scheme-dark" 
              />
            </div>
            {(startDate || endDate) && (
               <button 
                onClick={() => { setStartDate(''); setEndDate(''); }}
                className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-xl"
               >
                 <X className="w-4 h-4" />
               </button>
            )}
          </div>
        </div>
      </div>

      {/* Status Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-orange-50 dark:bg-orange-950/20 border border-orange-100 dark:border-orange-900/30 p-6 rounded-[2rem] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white dark:bg-orange-900 rounded-2xl flex items-center justify-center shadow-sm">
              <Clock className="w-6 h-6 text-orange-600 dark:text-orange-400" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-orange-400 uppercase tracking-widest">{t('waitingList')}</p>
              <p className="text-2xl font-black text-orange-800 dark:text-orange-400">{stats.waiting}</p>
            </div>
          </div>
        </div>
        <div className="bg-purple-50 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/30 p-6 rounded-[2rem] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white dark:bg-purple-900 rounded-2xl flex items-center justify-center shadow-sm">
              <CalendarDays className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-purple-400 uppercase tracking-widest">{t('scheduled')}</p>
              <p className="text-2xl font-black text-purple-800 dark:text-purple-400">{stats.scheduled}</p>
            </div>
          </div>
        </div>
        <div className="bg-green-50 dark:bg-green-950/20 border border-green-100 dark:border-green-900/30 p-6 rounded-[2rem] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white dark:bg-green-900 rounded-2xl flex items-center justify-center shadow-sm">
              <CheckCircle2 className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-green-400 uppercase tracking-widest">{t('operated')}</p>
              <p className="text-2xl font-black text-green-800 dark:text-green-400">{stats.operated}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          placeholder={t('search')}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-12 pr-6 py-4 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[2rem] shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all dark:text-white"
        />
      </div>

      {filteredPatients.length > 0 ? (
        <div className="space-y-12">
          {(Object.entries(groupedPatients) as [keyof typeof groupedPatients, Patient[]][]).map(([status, list]) => (
            list.length > 0 && (
              <div key={status} className="space-y-4">
                <div className="flex items-center gap-3 px-2">
                  <div className={cn(
                    "w-2 h-6 rounded-full",
                    status === 'Waiting' ? "bg-orange-500" : status === 'Scheduled' ? "bg-purple-500" : "bg-green-500"
                  )} />
                  <h3 className="text-lg font-bold text-slate-800 dark:text-slate-200">
                    {status === 'Waiting' ? t('waitingList') : status === 'Scheduled' ? t('scheduled') : t('operated')}
                    <span className="ml-2 text-sm font-medium text-slate-400">({list.length})</span>
                  </h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {list.map((patient) => (
                    <Link
                      key={patient.id}
                      to={`/patients/${patient.id}`}
                    >
                      <motion.div 
                        whileHover={{ y: -4 }}
                        className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all"
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div className={cn(
                            "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                            patient.priorityLevel === 'Urgent' ? "bg-red-50 text-red-600 dark:bg-red-950/30 dark:text-red-400" :
                            patient.priorityLevel === 'Moderate' ? "bg-orange-50 text-orange-600 dark:bg-orange-950/30 dark:text-orange-400" :
                            "bg-blue-50 text-blue-600 dark:bg-blue-950/30 dark:text-blue-400"
                          )}>
                            {patient.priorityLevel}
                          </div>
                          <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-tighter">#{patient.nationalId}</p>
                        </div>
                        
                        <h4 className="font-extrabold text-slate-900 dark:text-white text-lg mb-2 truncate">{patient.fullName}</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-4 h-8">{patient.diagnosis}</p>
                        
                        <div className="pt-4 border-t border-slate-50 dark:border-slate-800 flex items-center justify-between">
                          <div className="flex items-center gap-2 text-slate-400">
                            <Calendar className="w-3.5 h-3.5" />
                            <span className="text-[10px] font-bold">
                              {patient.scheduledDate || patient.completedAt ? formatDate(patient.scheduledDate || patient.completedAt) : 'Not set'}
                            </span>
                          </div>
                          {dept === 'all' && (
                            <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest">{patient.department}</span>
                          )}
                        </div>
                      </motion.div>
                    </Link>
                  ))}
                </div>
              </div>
            )
          ))}
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 p-12 text-center transition-colors">
          <div className="w-20 h-20 bg-slate-50 dark:bg-slate-800 rounded-3xl flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="w-10 h-10 text-slate-300 dark:text-slate-700" />
          </div>
          <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-2">No patients found</h3>
          <p className="text-slate-500 dark:text-slate-400 max-w-sm mx-auto">Try adjusting your search query or check back later.</p>
        </div>
      )}
    </div>
  );
};

export default DepartmentView;
