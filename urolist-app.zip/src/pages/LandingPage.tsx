import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  ClipboardList as UrologyIcon, 
  Activity, 
  Users, 
  Calendar, 
  Clock, 
  ShieldCheck, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Building2, 
  Sparkles, 
  ChevronRight, 
  ArrowRight, 
  Lock, 
  Database, 
  Smartphone, 
  MessageSquare, 
  Search, 
  Filter, 
  Globe, 
  Sun, 
  Moon, 
  LogIn, 
  Stethoscope, 
  HeartPulse, 
  FileSpreadsheet, 
  UserCheck, 
  Layers, 
  Zap, 
  ChevronLeft
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';
import { cn } from '../lib/utils';
import Branding from '../components/Branding';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthorized } = useAuth();
  const { language, setLanguage, theme, setTheme } = useUI();
  const [activeTab, setActiveTab] = useState<'all' | 'onco' | 'andro' | 'female' | 'pedia'>('all');

  const isAr = language === 'ar';

  const departments = [
    {
      id: 'onco',
      titleEn: 'Onco-urology',
      titleAr: 'أورام المسالك البولية',
      descEn: 'Specialized management for oncological surgical queues, radical nephrectomies, and bladder tumor resections with urgent priority tracking.',
      descAr: 'إدارة متخصصة لقوائم جراحات أورام الكلى والمثانة والبروستاتا مع تتبع دقيق لأولويات الحالات العاجلة.',
      icon: Activity,
      color: 'from-rose-500 to-red-600',
      badgeBg: 'bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 border-red-100 dark:border-red-900/30'
    },
    {
      id: 'andro',
      titleEn: 'Andrology',
      titleAr: 'أمراض الذكورة والجراحة الدقيقة',
      descEn: 'Micro-surgical waiting lists, fertility procedures, and confidential patient records managed with role-based access control.',
      descAr: 'متابعة عمليات الميكروسكوب والذكورة وحفظ السجلات بسرية تامة ووفق أعلى معايير الخصوصية.',
      icon: HeartPulse,
      color: 'from-indigo-500 to-purple-600',
      badgeBg: 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border-indigo-100 dark:border-indigo-900/30'
    },
    {
      id: 'female',
      titleEn: 'Female Urology',
      titleAr: 'المسالك البولية النسائية',
      descEn: 'Pelvic floor reconstructive lists, urodynamic procedures, and structured pre-operative document management.',
      descAr: 'تنظيم جراحات حوض وسلس البول للنساء وإرفاق نتائج الفحوصات والدراسات الديناميكية قبل العملية.',
      icon: Stethoscope,
      color: 'from-emerald-500 to-teal-600',
      badgeBg: 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30'
    },
    {
      id: 'pedia',
      titleEn: 'Pediatric Urology',
      titleAr: 'جراحة مسالك الأطفال',
      descEn: 'Congenital anomaly repair schedules, specialized timelines, and direct family communication via WhatsApp.',
      descAr: 'متابعة مواعيد إصلاح العيوب الخلقية للأطفال مع إمكانية التواصل المباشر مع أولياء الأمور عبر الواتساب.',
      icon: Sparkles,
      color: 'from-amber-500 to-orange-600',
      badgeBg: 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 border-amber-100 dark:border-amber-900/30'
    }
  ];

  const features = [
    {
      icon: Layers,
      titleEn: 'Dynamic Waiting List Queue',
      titleAr: 'قوائم انتظار ديناميكية ومرتبة',
      descEn: 'Sort patients seamlessly by urgency (Urgent, Moderate, Routine), department, or assigned doctor.',
      descAr: 'ترتيب فوري للمرضى حسب مستوى الأولوية (عاجل، متوسط، عادي)، القسم التخصصي، أو الطبيب المعالج.'
    },
    {
      icon: ShieldCheck,
      titleEn: 'Role-Based Access Control',
      titleAr: 'صلاحيات وظيفية دقيقة للفرق',
      descEn: 'Granular permissions for Consultants, Surgeons, Nurses, and Coordinators ensuring strict data governance.',
      descAr: 'صلاحيات مخصصة لكل من الاستشاريين، الجراحين، تمريض العمليات، والمنسقين لضمان سلامة البيانات.'
    },
    {
      icon: FileText,
      titleEn: 'Medical Attachments & Notes',
      titleAr: 'المرفقات والملاحظات الطبية',
      descEn: 'Attach CT scans, lab reports, and surgical consent forms directly to patient profiles.',
      descAr: 'إرفاق الأشعة والتحاليل وتقارير الجراحة وإقرارات المريض مباشرة في الملف الطبي الإلكتروني.'
    },
    {
      icon: Clock,
      titleEn: 'Real-Time Audit Trail',
      titleAr: 'سجل نشاطات حقيقي ومؤرخ',
      descEn: 'Every status update, note addition, or schedule change is logged with timestamp and user details.',
      descAr: 'تسجيل تلقائي لكل تعديل أو تغيير حالة أو إضافة ملاحظة مع توثيق اسم المستحدم والتاريخ بالتفصيل.'
    },
    {
      icon: MessageSquare,
      titleEn: 'Instant WhatsApp Integration',
      titleAr: 'تواصل مباشر عبر الواتساب',
      descEn: 'Notify patients about scheduled procedure dates or pre-op requirements with one click.',
      descAr: 'إرسال التنبيهات والتعليمات الطبية ومواعيد العمليات للمرضى بضغطة زر عبر الواتساب.'
    },
    {
      icon: FileSpreadsheet,
      titleEn: 'Advanced PDF & Excel Reports',
      titleAr: 'تقارير وطباعة وافية (PDF / Excel)',
      descEn: 'Generate operational reports, completion statistics, and print-ready waiting lists instantly.',
      descAr: 'استخراج تقارير إحصائية، وطباعة قوائم العمليات اليومية أو الأسبوعية بصيغ PDF و Excel بكل سهولة.'
    }
  ];

  const demoPatients = [
    {
      nameAr: 'أحمد محمود العلي',
      nameEn: 'Ahmed Mahmoud Al-Ali',
      deptAr: 'أورام المسالك',
      deptEn: 'Onco-urology',
      priority: 'Urgent',
      status: 'Scheduled',
      date: '2026-07-25',
      doctor: 'د. محمد صابر'
    },
    {
      nameAr: 'سارة خالد السيد',
      nameEn: 'Sara Khaled Al-Sayed',
      deptAr: 'المسالك النسائية',
      deptEn: 'Female Urology',
      priority: 'Moderate',
      status: 'Waiting List',
      date: '2026-07-28',
      doctor: 'د. فاطمة الزهراء'
    },
    {
      nameAr: 'يوسف عمر حسن',
      nameEn: 'Youssef Omar Hassan',
      deptAr: 'مسالك الأطفال',
      deptEn: 'Pediatric Urology',
      priority: 'Routine',
      status: 'Operated',
      date: '2026-07-20',
      doctor: 'د. أحمد الكردي'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 selection:bg-blue-500 selection:text-white transition-colors duration-300 font-sans relative overflow-x-hidden">
      
      {/* Background Glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-gradient-to-b from-blue-200/40 via-indigo-100/20 to-transparent dark:from-blue-900/20 dark:via-indigo-900/10 dark:to-transparent rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-96 -left-40 w-96 h-96 bg-blue-300/20 dark:bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-[1200px] -right-40 w-96 h-96 bg-indigo-300/20 dark:bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Navbar */}
      <nav className="sticky top-0 z-50 backdrop-blur-xl bg-white/80 dark:bg-slate-900/80 border-b border-slate-200/60 dark:border-slate-800/80 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Brand Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('/')}>
            <div className="w-11 h-11 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/25 transform rotate-3 hover:rotate-0 transition-transform duration-300">
              <UrologyIcon className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-tight text-slate-900 dark:text-white">UroList</span>
                <span className="text-[10px] font-extrabold bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 px-2 py-0.5 rounded-full uppercase tracking-wider">
                  v2.5
                </span>
              </div>
              <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                {isAr ? 'نظام إدارة قوائم عمليات المسالك' : 'Surgical Waiting List System'}
              </p>
            </div>
          </div>

          {/* Nav Items & Actions */}
          <div className="flex items-center gap-3">
            {/* Language Switcher */}
            <button
              onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
              className="p-2.5 bg-slate-100 dark:bg-slate-800/80 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center gap-1.5 text-xs font-bold transition-all"
              title="Change Language"
            >
              <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>{isAr ? 'English' : 'العربية'}</span>
            </button>

            {/* Theme Switcher */}
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2.5 bg-slate-100 dark:bg-slate-800/80 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-all"
              title="Toggle Theme"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
            </button>

            {/* Main Action Button */}
            {user && isAuthorized ? (
              <button
                onClick={() => navigate('/')}
                className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-2.5 px-5 rounded-xl shadow-lg shadow-blue-500/25 transition-all transform active:scale-95 text-xs sm:text-sm"
              >
                <span>{isAr ? 'لوحة التحكم' : 'Dashboard'}</span>
                {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              </button>
            ) : (
              <button
                onClick={() => navigate('/login')}
                className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-2.5 px-5 rounded-xl shadow-lg shadow-blue-500/25 transition-all transform active:scale-95 text-xs sm:text-sm"
              >
                <LogIn className="w-4 h-4" />
                <span>{isAr ? 'تسجيل الدخول' : 'Sign In'}</span>
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-12 sm:pt-20 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-4xl mx-auto">
          
          {/* Top Badge */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 dark:bg-blue-950/60 border border-blue-200/60 dark:border-blue-800/60 rounded-full text-blue-700 dark:text-blue-300 text-xs sm:text-sm font-bold mb-6 shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400 animate-pulse" />
            <span>{isAr ? 'المنصة الرقمية المتكاملة لأقسام جراحة المسالك البولية' : 'Integrated Digital Platform for Urology Surgery Units'}</span>
          </motion.div>

          {/* Hero Headline */}
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 dark:text-white tracking-tight leading-[1.15] mb-6"
          >
            {isAr ? (
              <>
                إدارة أسرع وأدق <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400">لقوائم عمليات المسالك البولية</span>
              </>
            ) : (
              <>
                Smarter Waiting Lists. <br className="hidden sm:inline" />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400">Accelerated Patient Care.</span>
              </>
            )}
          </motion.h1>

          {/* Hero Subtitle */}
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-base sm:text-lg text-slate-600 dark:text-slate-300 font-medium leading-relaxed max-w-3xl mx-auto mb-10"
          >
            {isAr ? (
              'نظام UroList يُمكّن الفرق الطبية والاستشاريين وتمريض العمليات والمنسقين من تنظيم جدولة العمليات الجراحية، تتبع الأولويات العاجلة، وتبادل الملاحظات والمرفقات الطبية لحظة بلحظة وبأعلى معايير الأمان.'
            ) : (
              'UroList empowers surgical teams, consultants, operating room nurses, and coordinators to streamline surgical scheduling, track priority queues, and manage clinical documentation securely in real time.'
            )}
          </motion.p>

          {/* Hero CTAs */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
          >
            <button
              onClick={() => navigate('/login')}
              className="w-full sm:w-auto flex items-center justify-center gap-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-4 px-8 rounded-2xl shadow-xl shadow-blue-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-base"
            >
              <LogIn className="w-5 h-5" />
              <span>{isAr ? 'تسجيل الدخول للنظام' : 'Access System Login'}</span>
              {isAr ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
            </button>

            <a
              href="#departments"
              className="w-full sm:w-auto flex items-center justify-center gap-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-800 text-slate-700 dark:text-slate-200 font-bold py-4 px-8 rounded-2xl shadow-sm transition-all text-base"
            >
              <span>{isAr ? 'استكشف الأقسام والمميزات' : 'Explore Departments & Features'}</span>
            </a>
          </motion.div>

          {/* Stats Metrics Strip */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="grid grid-cols-2 lg:grid-cols-4 gap-4 p-4 sm:p-6 bg-white/70 dark:bg-slate-900/70 border border-slate-200/80 dark:border-slate-800/80 rounded-3xl backdrop-blur-md shadow-xl shadow-slate-200/50 dark:shadow-none"
          >
            <div className="p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 text-center">
              <div className="text-2xl sm:text-3xl font-black text-blue-600 dark:text-blue-400 mb-1">4</div>
              <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                {isAr ? 'أقسام جراحية تخصصية' : 'Specialized Units'}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 text-center">
              <div className="text-2xl sm:text-3xl font-black text-emerald-600 dark:text-emerald-400 mb-1">100%</div>
              <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                {isAr ? 'تتبع فوري وموثق' : 'Real-time Audit Logs'}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 text-center">
              <div className="text-2xl sm:text-3xl font-black text-purple-600 dark:text-purple-400 mb-1">3</div>
              <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                {isAr ? 'مستويات تصنيف الأولوية' : 'Urgency Priority Levels'}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 text-center">
              <div className="text-2xl sm:text-3xl font-black text-amber-600 dark:text-amber-400 mb-1">24/7</div>
              <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                {isAr ? 'حماية ووصول آمن' : 'Secured Medical Access'}
              </div>
            </div>
          </motion.div>

        </div>
      </section>

      {/* Interactive Queue Preview Demo */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] p-6 sm:p-10 shadow-2xl shadow-slate-200/50 dark:shadow-none overflow-hidden relative">
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <div className="inline-flex items-center gap-2 text-blue-600 dark:text-blue-400 text-xs font-bold uppercase tracking-wider mb-2">
                <Activity className="w-4 h-4" />
                <span>{isAr ? 'عرض حي لواجهة النظام' : 'Live Interactive System Preview'}</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
                {isAr ? 'قائمة انتظار العمليات التفاعلية' : 'Surgical Waiting List View'}
              </h2>
            </div>

            <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl self-start md:self-auto text-xs font-bold">
              <span className="px-3 py-1.5 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-xl shadow-sm">
                {isAr ? 'جميع المرضى' : 'All Patients'}
              </span>
              <span className="px-3 py-1.5 text-slate-500 dark:text-slate-400">
                {isAr ? 'العاجل (1)' : 'Urgent (1)'}
              </span>
              <span className="px-3 py-1.5 text-slate-500 dark:text-slate-400">
                {isAr ? 'المجدول (1)' : 'Scheduled (1)'}
              </span>
            </div>
          </div>

          {/* Table / Cards Mockup */}
          <div className="space-y-4">
            {demoPatients.map((patient, idx) => (
              <div 
                key={idx}
                className="p-5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-blue-200 dark:hover:border-blue-800/60 transition-all shadow-sm"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center font-bold text-lg flex-shrink-0">
                    {idx + 1}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="font-extrabold text-slate-900 dark:text-white text-base">
                        {isAr ? patient.nameAr : patient.nameEn}
                      </h3>
                      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300">
                        {isAr ? patient.deptAr : patient.deptEn}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400 font-medium">
                      <span className="flex items-center gap-1">
                        <Stethoscope className="w-3.5 h-3.5 text-blue-500" />
                        {patient.doctor}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {patient.date}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-end sm:self-auto">
                  {/* Priority */}
                  <span className={cn(
                    "text-xs font-bold px-3 py-1 rounded-xl border",
                    patient.priority === 'Urgent' && "bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 border-red-200 dark:border-red-900/40",
                    patient.priority === 'Moderate' && "bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-900/40",
                    patient.priority === 'Routine' && "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700"
                  )}>
                    {patient.priority === 'Urgent' ? (isAr ? 'عاجل جداً' : 'Urgent') : 
                     patient.priority === 'Moderate' ? (isAr ? 'أولوية متوسطة' : 'Moderate') : 
                     (isAr ? 'روتيني' : 'Routine')}
                  </span>

                  {/* Status */}
                  <span className={cn(
                    "text-xs font-bold px-3 py-1 rounded-xl flex items-center gap-1.5",
                    patient.status === 'Scheduled' && "bg-blue-600 text-white",
                    patient.status === 'Waiting List' && "bg-orange-500 text-white",
                    patient.status === 'Operated' && "bg-emerald-600 text-white"
                  )}>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {patient.status === 'Scheduled' ? (isAr ? 'مجدول للعملية' : 'Scheduled') :
                     patient.status === 'Waiting List' ? (isAr ? 'قائمة الانتظار' : 'Waiting List') :
                     (isAr ? 'تمت العملية' : 'Operated')}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <p className="mt-6 text-center text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
            {isAr ? 'محاكاة لبعض البيانات المعروضة في النظام الحقيقي' : 'Simulated Sample Data View'}
          </p>

        </div>
      </section>

      {/* Specialized Departments */}
      <section id="departments" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 text-blue-600 dark:text-blue-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Building2 className="w-4 h-4" />
            <span>{isAr ? 'التخصصات والدعم الجراحي' : 'Specialized Units'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight mb-4">
            {isAr ? 'مُصمم لتغطية كافّة أقسام المسالك البولية' : 'Tailored for Every Urology Sub-Specialty'}
          </h2>
          <p className="text-slate-600 dark:text-slate-400 font-medium text-base">
            {isAr ? 'يحتوي النظام على وحدات مستقلة تضمن سهولة تصنيف المرضى بحسب طبيعة الجراحة والتخصص المطلوب.' : 'Dedicated modules for each sub-specialty ensure seamless patient organization and streamlined surgical queues.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {departments.map((dept) => {
            const Icon = dept.icon;
            return (
              <motion.div
                key={dept.id}
                whileHover={{ y: -4 }}
                className="p-8 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl shadow-xl shadow-slate-200/50 dark:shadow-none flex flex-col justify-between relative overflow-hidden group"
              >
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={cn("w-14 h-14 rounded-2xl bg-gradient-to-br flex items-center justify-center text-white shadow-lg", dept.color)}>
                      <Icon className="w-7 h-7" />
                    </div>
                    <span className={cn("text-xs font-extrabold px-3 py-1 rounded-full border", dept.badgeBg)}>
                      {isAr ? dept.titleAr : dept.titleEn}
                    </span>
                  </div>

                  <h3 className="text-xl font-extrabold text-slate-900 dark:text-white mb-2">
                    {isAr ? dept.titleAr : dept.titleEn}
                  </h3>

                  <p className="text-sm text-slate-600 dark:text-slate-400 font-medium leading-relaxed">
                    {isAr ? dept.descAr : dept.descEn}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold text-blue-600 dark:text-blue-400">
                  <span>{isAr ? 'تخصيص القائمة وتتبع الحالات' : 'Customized List & Queue Tracking'}</span>
                  <ChevronRight className={cn("w-4 h-4 transform transition-transform group-hover:translate-x-1", isAr && "rotate-180 group-hover:-translate-x-1")} />
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Key Features */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 text-blue-600 dark:text-blue-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Zap className="w-4 h-4" />
            <span>{isAr ? 'الإمكانيات والخصائص' : 'Key Features'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight mb-4">
            {isAr ? 'لماذا يعتمد الجراحون على UroList؟' : 'Why Surgical Teams Choose UroList?'}
          </h2>
          <p className="text-slate-600 dark:text-slate-400 font-medium text-base">
            {isAr ? 'مجموعة من الأدوات المتقدمة المصممة خصيصاً للحد من الأخطاء وتنظيم المواعيد وتسهيل العمل الجماعي.' : 'Advanced tools engineered specifically to eliminate scheduling friction, reduce errors, and foster medical teamwork.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div 
                key={idx}
                className="p-8 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl shadow-lg shadow-slate-200/40 dark:shadow-none hover:border-blue-300 dark:hover:border-blue-800/80 transition-all"
              >
                <div className="w-12 h-12 bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center mb-6">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-extrabold text-slate-900 dark:text-white mb-2">
                  {isAr ? feat.titleAr : feat.titleEn}
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400 font-medium leading-relaxed">
                  {isAr ? feat.descAr : feat.descEn}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* How it works steps */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white rounded-[2.5rem] p-8 sm:p-14 shadow-2xl relative overflow-hidden">
          
          <div className="text-center max-w-3xl mx-auto mb-12">
            <span className="text-xs font-bold text-blue-400 uppercase tracking-widest">
              {isAr ? 'خطوات العمل البسيطة' : 'How It Works'}
            </span>
            <h2 className="text-3xl sm:text-4xl font-black mt-2 mb-4">
              {isAr ? 'رحلة المريض من الإضافة حتى إتمام الجراحة' : 'Patient Journey from Entry to Post-Op'}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm">
              <div className="w-10 h-10 bg-blue-600 text-white font-black rounded-xl flex items-center justify-center mb-4 text-lg">1</div>
              <h4 className="font-extrabold text-lg mb-2">{isAr ? 'تسجيل المريض' : 'Patient Registration'}</h4>
              <p className="text-xs text-slate-300 font-medium leading-relaxed">
                {isAr ? 'إدخال البيانات الأساسية ورقم الهوية والقسم وتحديد درجة الأولوية.' : 'Enter demographics, national ID, target unit, and initial urgency.'}
              </p>
            </div>

            <div className="p-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm">
              <div className="w-10 h-10 bg-blue-600 text-white font-black rounded-xl flex items-center justify-center mb-4 text-lg">2</div>
              <h4 className="font-extrabold text-lg mb-2">{isAr ? 'الجدولة والتنسيق' : 'Scheduling & Review'}</h4>
              <p className="text-xs text-slate-300 font-medium leading-relaxed">
                {isAr ? 'مراجعة الطبيب المعالج، تحديد تاريخ العملية، وإجراء الفحوصات.' : 'Surgeon reviews diagnosis, sets operation date, and prepares consent.'}
              </p>
            </div>

            <div className="p-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm">
              <div className="w-10 h-10 bg-blue-600 text-white font-black rounded-xl flex items-center justify-center mb-4 text-lg">3</div>
              <h4 className="font-extrabold text-lg mb-2">{isAr ? 'التنبيه والمتابعة' : 'Notification & Prep'}</h4>
              <p className="text-xs text-slate-300 font-medium leading-relaxed">
                {isAr ? 'إرسال التنبيهات للمريض عبر الواتساب ومتابعة تمريض العمليات.' : 'Automated WhatsApp alerts to patient & active pre-op nursing check.'}
              </p>
            </div>

            <div className="p-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm">
              <div className="w-10 h-10 bg-emerald-500 text-white font-black rounded-xl flex items-center justify-center mb-4 text-lg">4</div>
              <h4 className="font-extrabold text-lg mb-2">{isAr ? 'الإتمام والأرشفة' : 'Completion & Archive'}</h4>
              <p className="text-xs text-slate-300 font-medium leading-relaxed">
                {isAr ? 'تحديث حالة العملية إلى "تمت" وأرشفة الملف تلقائياً بالسجلات.' : 'Update status to "Operated" and automatically archive complete file.'}
              </p>
            </div>
          </div>

        </div>
      </section>

      {/* Call to Action Banner */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto text-center">
        <div className="p-10 sm:p-16 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] shadow-2xl shadow-slate-200/50 dark:shadow-none relative overflow-hidden">
          
          <div className="w-16 h-16 bg-blue-600 rounded-3xl flex items-center justify-center shadow-xl shadow-blue-500/30 mx-auto mb-6 transform rotate-6">
            <UrologyIcon className="w-8 h-8 text-white -rotate-6" />
          </div>

          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight mb-4">
            {isAr ? 'جاهز لبدء تنظيم قائمة انتظار العمليات؟' : 'Ready to Streamline Your Operating Queue?'}
          </h2>

          <p className="text-slate-600 dark:text-slate-300 font-medium text-base max-w-2xl mx-auto mb-8">
            {isAr ? 'قم بتسجيل الدخول باستخدام حساب Google المعتمد للوصول المباشر لوحدة العمليات ولوحة التحكم.' : 'Sign in using your authorized Google credentials to access the live waiting list dashboard.'}
          </p>

          <button
            onClick={() => navigate('/login')}
            className="inline-flex items-center gap-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-4 px-10 rounded-2xl shadow-xl shadow-blue-500/30 transition-all transform hover:-translate-y-0.5 text-base"
          >
            <LogIn className="w-5 h-5" />
            <span>{isAr ? 'تسجيل الدخول الآن' : 'Sign In Now'}</span>
            {isAr ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-slate-200 dark:border-slate-800/80 bg-white dark:bg-slate-950 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center gap-6 text-center">
          
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-xl flex items-center justify-center">
              <UrologyIcon className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg font-black tracking-tight text-slate-900 dark:text-white">UroList</span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md font-medium">
            {isAr ? 'نظام متخصص لإدارة ومتابعة قوائم انتظار العمليات الجراحية لأقسام المسالك البولية.' : 'Specialized surgical waiting list & patient queue management platform for urology departments.'}
          </p>

          <div className="pt-2">
            <Branding variant="large" />
          </div>

        </div>
      </footer>

    </div>
  );
};

export default LandingPage;
