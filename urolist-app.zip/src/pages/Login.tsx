import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';
import { Navigate, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { ClipboardList as UrologyIcon, Chrome, Globe, Moon, Sun, Info } from 'lucide-react';
import { cn } from '../lib/utils';
import Branding from '../components/Branding';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthorized, signIn, loading, error } = useAuth();
  const { t, language, setLanguage, theme, setTheme } = useUI();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50 dark:bg-slate-950">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (user && isAuthorized) {
    return <Navigate to="/" />;
  }

  if (user && !isAuthorized) {
    return <Navigate to="/access-denied" />;
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-6 relative overflow-hidden transition-colors duration-300">
      {/* Background Orbs */}
      <div className="absolute top-0 -left-20 w-96 h-96 bg-blue-100 dark:bg-blue-900/10 rounded-full blur-3xl opacity-50" />
      <div className="absolute bottom-0 -right-20 w-96 h-96 bg-indigo-100 dark:bg-indigo-900/10 rounded-full blur-3xl opacity-50" />

      {/* Floating Controls */}
      <div className="absolute top-6 right-6 flex items-center gap-2 z-20">
        <button 
          onClick={() => navigate('/landing')}
          className="p-3 bg-white dark:bg-slate-900 rounded-2xl shadow-lg shadow-slate-200/50 dark:shadow-none border border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 flex items-center gap-2 transition-all text-xs font-bold"
        >
          <Info className="w-4 h-4 text-blue-500" />
          <span>{language === 'ar' ? 'عن النظام' : 'About System'}</span>
        </button>
        <button 
          onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
          className="p-3 bg-white dark:bg-slate-900 rounded-2xl shadow-lg shadow-slate-200/50 dark:shadow-none border border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 flex items-center gap-2 transition-all"
        >
          <Globe className="w-5 h-5" />
          <span className="text-xs font-bold uppercase">{language === 'ar' ? 'English' : 'العربية'}</span>
        </button>
        <button 
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          className="p-3 bg-white dark:bg-slate-900 rounded-2xl shadow-lg shadow-slate-200/50 dark:shadow-none border border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-orange-500 dark:hover:text-yellow-400 transition-all"
        >
          {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl shadow-slate-200/50 dark:shadow-none p-8 sm:p-12 z-10 border border-slate-100 dark:border-slate-800"
      >
        <div className={cn("flex flex-col items-center text-center mb-10", language === 'ar' ? "text-right" : "text-center")}>
          <div className="w-20 h-20 bg-blue-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-blue-200 dark:shadow-blue-900/20 mb-6 transform rotate-6">
            <UrologyIcon className="text-white w-10 h-10 -rotate-6" />
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-2">
            {t('loginTitle')}
          </h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium leading-relaxed">
            {t('loginSub')}
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/30 rounded-2xl flex items-start gap-3">
            <p className="text-sm text-red-600 dark:text-red-400 font-medium">{error}</p>
          </div>
        )}

        <button
          onClick={signIn}
          disabled={loading}
          className="w-full flex items-center justify-center gap-4 bg-white dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 hover:border-blue-100 dark:hover:border-blue-900 hover:bg-blue-50 dark:hover:bg-slate-700/50 py-4 px-6 rounded-2xl transition-all duration-300 group shadow-sm"
        >
          {loading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-blue-500" />
          ) : (
            <>
              <div className="w-8 h-8 bg-slate-50 dark:bg-slate-700 rounded-lg flex items-center justify-center group-hover:bg-white dark:group-hover:bg-slate-600 transition-colors shadow-sm">
                <Chrome className="w-5 h-5 text-slate-600 dark:text-slate-300 group-hover:text-blue-600 dark:group-hover:text-blue-400" />
              </div>
              <span className="font-bold text-slate-700 dark:text-slate-200 group-hover:text-blue-700 dark:group-hover:text-blue-400">
                {t('continueGoogle')}
              </span>
            </>
          )}
        </button>

        <p className="mt-8 text-center text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest">
          Secured by Firebase Auth & Google
        </p>

        <div className="mt-12 pt-8 border-t border-slate-100 dark:border-slate-800 text-center space-y-4">
          <p className="text-xs text-slate-400 dark:text-slate-500">
            Internal Use Only. Access is restricted to authorized medical staff and department coordinators.
          </p>
          
          <div className="pt-2">
            <Branding variant="small" />
          </div>
        </div>
      </motion.div>

      <div className="mt-12 flex items-center gap-8 text-slate-400 dark:text-slate-600 font-medium text-sm">
        <span className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 bg-green-400 rounded-full shadow-[0_0_8px_rgba(74,222,128,0.5)]" />
          System Active
        </span>
        <span>Version 2.5.0</span>
      </div>
    </div>
  );
};

export default Login;
