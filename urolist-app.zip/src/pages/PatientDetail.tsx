import React, { useEffect, useState, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  doc, 
  getDoc, 
  onSnapshot, 
  updateDoc, 
  collection, 
  query, 
  orderBy, 
  serverTimestamp,
  addDoc
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Patient, PatientNote, ActivityLog, OperationStatus } from '../types';
import { formatDate, formatDateTime, cn } from '../lib/utils';
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  MapPin, 
  IdCard, 
  FileText, 
  Upload, 
  Plus, 
  MessageSquare,
  CheckCircle2,
  Trash2,
  AlertTriangle,
  History,
  FilePlus,
  MoreHorizontal,
  Globe,
  Edit2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';
import { uploadFile } from '../services/storage';
import { logActivity } from '../services/firestore';
import AddPatientModal from '../components/AddPatientModal';

const PatientDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { profile, effectiveRole } = useAuth();
  const [patient, setPatient] = useState<Patient | null>(null);
  const [notes, setNotes] = useState<PatientNote[]>([]);
  const [activity, setActivity] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'notes' | 'files' | 'activity'>('notes');
  const [newNote, setNewNote] = useState('');
  const [noteType, setNoteType] = useState<'doctor' | 'nurse' | 'coordinator'>('doctor');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!id) return;

    // Real-time patient data
    const unsubPatient = onSnapshot(doc(db, 'patients', id), (doc) => {
      if (doc.exists()) {
        setPatient({ id: doc.id, ...doc.data() } as Patient);
      } else {
        toast.error("Patient not found");
        navigate('/');
      }
      setLoading(false);
    });

    // Real-time notes
    const qNotes = query(collection(db, 'patients', id, 'notes'), orderBy('createdAt', 'desc'));
    const unsubNotes = onSnapshot(qNotes, (snap) => {
      setNotes(snap.docs.map(d => ({ id: d.id, ...d.data() } as PatientNote)));
    });

    // Activity Logs for this patient
    const qLogs = query(collection(db, 'activityLogs'), orderBy('timestamp', 'desc'));
    // Filter client-side if needed or use composite index. For now we use simple filter if possible.
    const unsubLogs = onSnapshot(qLogs, (snap) => {
      setActivity(snap.docs.map(d => ({ id: d.id, ...d.data() } as ActivityLog)).filter(l => l.patientId === id));
    });

    return () => {
      unsubPatient();
      unsubNotes();
      unsubLogs();
    };
  }, [id]);

  const handleStatusChange = async (status: OperationStatus) => {
    if (!id || !patient) return;
    
    if (status === 'Waiting' && patient.operationStatus === 'Cancelled') {
      if (!window.confirm(`Are you sure you want to restore ${patient.fullName} to the waiting list?`)) return;
    }

    try {
      const updateData: any = { operationStatus: status, updatedAt: serverTimestamp() };
      if (status === 'Operated') {
        updateData.completedAt = serverTimestamp();
      }
      await updateDoc(doc(db, 'patients', id), updateData);
      
      await logActivity(`Status changed to ${status}`, id, patient.fullName);
      
      toast.success(`Status updated to ${status}`);
    } catch (err) {
      toast.error("Failed to update status");
    }
  };

  const handleDelete = async () => {
    if (!id || !patient || effectiveRole !== 'admin') return;
    
    const confirmed = window.confirm(`Are you absolutely sure you want to permanently delete ${patient.fullName}? This action cannot be undone.`);
    if (!confirmed) return;

    const loadingToast = toast.loading("Deleting patient record...");
    try {
      // In a real app, you might want to delete subcollections too (notes)
      // but for now we'll just delete the patient doc.
      // Firebase rules will block non-admins.
      await updateDoc(doc(db, 'patients', id), { operationStatus: 'Cancelled', updatedAt: serverTimestamp() });
      // Actually the user asked for full delete option too.
      // But let's check if they want soft or hard delete. 
      // "delete permanently" -> hard delete.
      
      // I need to use the service if available or just delete directly.
      // I'll delete directly since I have access to db and doc here.
      const { deleteDoc: firestoreDeleteDoc } = await import('firebase/firestore');
      await firestoreDeleteDoc(doc(db, 'patients', id));

      await logActivity(`Permanently deleted patient: ${patient.fullName}`, id);

      toast.success("Patient record deleted successfully", { id: loadingToast });
      navigate('/');
    } catch (err) {
      toast.error("Failed to delete patient record", { id: loadingToast });
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !newNote.trim() || !profile) return;

    try {
      await addDoc(collection(db, 'patients', id, 'notes'), {
        patientId: id,
        content: newNote,
        userId: profile.uid,
        userName: profile.displayName,
        userRole: profile.role,
        type: noteType,
        createdAt: serverTimestamp()
      });

      await logActivity(`Added ${noteType} note`, id, patient?.fullName);

      setNewNote('');
      toast.success("Note added successfully");
    } catch (err) {
      toast.error("Failed to add note");
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !id || !patient || !profile) return;

    const loadingToast = toast.loading("Uploading file...");
    try {
      const path = `patients/${id}/${Date.now()}_${file.name}`;
      const attachment = await uploadFile(file, path);
      
      const newAttachment = {
        ...attachment,
        uploadedBy: profile.displayName,
        uploaderRole: profile.role
      };
      
      const newAttachments = [...(patient.attachments || []), newAttachment];
      await updateDoc(doc(db, 'patients', id), { 
        attachments: newAttachments,
        updatedAt: serverTimestamp()
      });

      await logActivity(`Uploaded file: ${file.name}`, id, patient.fullName);

      toast.success("File uploaded successfully", { id: loadingToast });
    } catch (err) {
      toast.error("Upload failed", { id: loadingToast });
    }
  };

  if (loading || !patient) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500" />
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-20">
      {/* Detail Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-4">
          <Link 
            to={`/departments/${patient.department.toLowerCase().replace(/ /g, '-')}`} 
            className="flex items-center gap-2 text-slate-400 hover:text-blue-600 font-bold text-xs uppercase tracking-widest transition-colors mb-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to {patient.department}
          </Link>
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-blue-600 rounded-3xl flex items-center justify-center text-white text-2xl font-extrabold shadow-xl shadow-blue-200">
              {patient.fullName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-3 mb-1">
                <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">{patient.fullName}</h1>
                <span className={cn(
                  "px-3 py-1 rounded-xl text-xs font-bold uppercase",
                  patient.operationStatus === 'Waiting' ? "bg-slate-100 text-slate-600" :
                  patient.operationStatus === 'Scheduled' ? "bg-purple-100 text-purple-600" : 
                  patient.operationStatus === 'Operated' ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"
                )}>
                  {patient.operationStatus}
                </span>
              </div>
              <div className="flex items-center gap-4 text-slate-500 font-medium text-sm">
                <span className="flex items-center gap-1.5"><IdCard className="w-4 h-4" /> {patient.nationalId}</span>
                <span className="flex items-center gap-1.5"><User className="w-4 h-4" /> {patient.age}y • {patient.gender}</span>
              </div>
              {patient.createdByName && (
                <div className="mt-2 inline-flex items-center gap-2 px-3 py-1 bg-slate-50 border border-slate-100 rounded-lg">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Added by:</span>
                  <span className="text-[11px] font-bold text-slate-700">{patient.createdByName}</span>
                  <span className="text-[10px] bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded font-bold uppercase">{patient.createdByRole}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {effectiveRole === 'admin' && (
            <button 
              onClick={() => setIsEditModalOpen(true)}
              className="px-6 py-3 bg-white text-blue-600 border border-blue-100 font-bold rounded-2xl hover:bg-blue-50 transition-all flex items-center gap-2 shadow-sm"
            >
              <Edit2 className="w-5 h-5" />
              Edit Details
            </button>
          )}

          {patient.operationStatus === 'Cancelled' && (
            <button 
              onClick={() => handleStatusChange('Waiting')}
              className="px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-2"
            >
              <History className="w-5 h-5" />
              Restore to Waiting List
            </button>
          )}

          {patient.operationStatus !== 'Operated' && patient.operationStatus !== 'Cancelled' && (
            <button 
              onClick={() => handleStatusChange('Operated')}
              className="px-6 py-3 bg-green-600 text-white font-bold rounded-2xl shadow-lg shadow-green-100 hover:bg-green-700 transition-all flex items-center gap-2"
            >
              <CheckCircle2 className="w-5 h-5" />
              Mark as Operated
            </button>
          )}
          
          {effectiveRole === 'admin' && (
            <button 
              onClick={handleDelete}
              className="px-6 py-3 bg-red-50 text-red-600 font-bold rounded-2xl hover:bg-red-100 transition-all flex items-center gap-2"
            >
              <Trash2 className="w-5 h-5" />
              Delete Permanently
            </button>
          )}

          <div className="relative group">
            <button className="p-3 bg-white border border-slate-200 rounded-2xl hover:bg-slate-50 transition-all">
              <MoreHorizontal className="w-6 h-6 text-slate-600" />
            </button>
            <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-100 py-2 opacity-0 group-hover:opacity-100 invisible group-hover:visible transition-all z-20">
              <button 
                onClick={() => handleStatusChange('Cancelled')}
                className="w-full px-4 py-3 text-left hover:bg-slate-50 text-slate-600 font-bold text-sm flex items-center gap-2"
              >
                <AlertTriangle className="w-4 h-4" /> Withdraw/Cancel
              </button>
              {patient.operationStatus !== 'Waiting' && (
                <button 
                  onClick={() => handleStatusChange('Waiting')}
                  className="w-full px-4 py-3 text-left hover:bg-slate-50 text-slate-600 font-bold text-sm flex items-center gap-2"
                >
                  <Clock className="w-4 h-4" /> Move to Waiting List
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Prominent Attachments Section (Quick Access) */}
      {patient.attachments && patient.attachments.length > 0 && (
        <section className="bg-white rounded-[2rem] border border-blue-100 shadow-sm p-8 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-slate-900 text-lg flex items-center gap-2">
              <Globe className="w-5 h-5 text-blue-600" />
              Medical Links & Files
            </h3>
            <span className="bg-blue-50 text-blue-600 px-3 py-1 rounded-lg text-xs font-bold uppercase">
              {patient.attachments.length} Attachments
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {patient.attachments.map((file, idx) => (
              <a 
                key={idx}
                href={file.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col p-4 bg-slate-50 rounded-2xl border border-transparent hover:border-blue-300 hover:bg-blue-50/50 transition-all group relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full -mr-12 -mt-12 group-hover:bg-blue-500/10 transition-colors" />
                <div className="flex items-center gap-3 mb-3 relative z-10">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm text-blue-600 group-hover:scale-110 transition-transform shrink-0">
                    {file.type === 'Link' ? <Globe className="w-5 h-5" /> : file.type.includes('image') ? <FilePlus className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-slate-800 text-sm truncate">{file.name}</p>
                    <div className="flex items-center gap-2">
                       <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{formatDate(file.uploadedAt)}</p>
                       {file.uploadedBy && (
                         <span className="text-[9px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded font-bold uppercase">by {file.uploadedBy}</span>
                       )}
                    </div>
                  </div>
                </div>
                {file.description && (
                  <p className="text-xs text-slate-500 font-medium italic pl-1 border-l-2 border-slate-200 ml-1 relative z-10 line-clamp-2">
                    {file.description}
                  </p>
                )}
                <div className="mt-4 flex items-center justify-center py-2 bg-white rounded-xl text-blue-600 text-xs font-bold shadow-sm opacity-0 group-hover:opacity-100 transition-all translate-y-2 group-hover:translate-y-0">
                  Open Document
                </div>
              </a>
            ))}
          </div>
        </section>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Patient Info Cards */}
        <div className="lg:col-span-1 space-y-6">
          <section className="bg-white rounded-[2rem] border border-slate-100 shadow-sm p-8 space-y-6">
            <h3 className="font-extrabold text-slate-900 text-lg flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              Medical Status
            </h3>
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 rounded-2xl">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Diagnosis</p>
                <p className="font-bold text-slate-800 leading-snug">{patient.diagnosis}</p>
              </div>
              {patient.operationStatus === 'Scheduled' && patient.scheduledDate && (
                <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100">
                  <p className="text-[10px] font-bold text-purple-400 uppercase tracking-widest mb-1">Operation Date</p>
                  <p className="font-bold text-purple-700 flex items-center gap-2">
                    <Calendar className="w-4 h-4" /> {formatDate(patient.scheduledDate)}
                  </p>
                </div>
              )}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 rounded-2xl">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Priority</p>
                  <p className={cn(
                    "font-bold",
                    patient.priorityLevel === 'Urgent' ? "text-red-600" : "text-slate-800"
                  )}>{patient.priorityLevel}</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Insurance</p>
                  <p className="font-bold text-slate-800">{patient.insuranceType}</p>
                  {patient.insuranceType === 'Other' && patient.insuranceOtherDetails && (
                    <p className="text-[10px] font-medium text-slate-500 mt-1 italic">{patient.insuranceOtherDetails}</p>
                  )}
                </div>
              </div>
            </div>
          </section>

          <section className="bg-white rounded-[2rem] border border-slate-100 shadow-sm p-8 space-y-6">
            <h3 className="font-extrabold text-slate-900 text-lg flex items-center gap-2">
              <Phone className="w-5 h-5 text-blue-600" />
              Contact Details
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm shrink-0">
                    <Phone className="w-5 h-5 text-slate-400" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-900">{patient.phoneNumber}</p>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Primary Phone</p>
                  </div>
                </div>
                <a 
                  href={`tel:${patient.phoneNumber}`}
                  className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors"
                >
                  <Phone className="w-4 h-4" />
                </a>
              </div>

              {patient.secondaryPhoneNumbers && patient.secondaryPhoneNumbers.map((phone, idx) => (
                <div key={idx} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm shrink-0">
                      <Phone className="w-5 h-5 text-slate-400" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900">{phone}</p>
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Secondary #{idx + 1}</p>
                    </div>
                  </div>
                  <a 
                    href={`tel:${phone}`}
                    className="p-2 bg-slate-200 text-slate-600 rounded-lg hover:bg-slate-300 transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                  </a>
                </div>
              ))}

              {patient.hasWhatsapp && (
                <div className="flex items-center justify-between p-4 bg-green-50/50 rounded-2xl border border-green-100/50">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm shrink-0">
                      <MessageSquare className="w-5 h-5 text-green-500" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900">{patient.whatsappNumber || patient.phoneNumber}</p>
                      <p className="text-xs text-green-600 font-bold uppercase tracking-widest">WhatsApp</p>
                    </div>
                  </div>
                  <a 
                    href={`https://wa.me/${(patient.whatsappNumber || patient.phoneNumber).replace(/\D/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 transition-colors"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </a>
                </div>
              )}

              <div className="flex items-start gap-4 p-4">
                <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-slate-400" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900">{patient.address}</p>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Primary Address</p>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* Dynamic Content Tabs */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden flex flex-col h-full min-h-[600px]">
            {/* Tabs Header */}
            <div className="flex items-center gap-8 px-8 border-b border-slate-100">
              <button 
                onClick={() => setActiveTab('notes')}
                className={cn(
                  "py-6 font-bold text-sm transition-all relative",
                  activeTab === 'notes' ? "text-blue-600" : "text-slate-400 hover:text-slate-600"
                )}
              >
                Medical Notes
                {activeTab === 'notes' && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600 rounded-t-full" />}
              </button>
              <button 
                onClick={() => setActiveTab('files')}
                className={cn(
                  "py-6 font-bold text-sm transition-all relative",
                  activeTab === 'files' ? "text-blue-600" : "text-slate-400 hover:text-slate-600"
                )}
              >
                Attachments ({patient.attachments?.length || 0})
                {activeTab === 'files' && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600 rounded-t-full" />}
              </button>
              <button 
                onClick={() => setActiveTab('activity')}
                className={cn(
                  "py-6 font-bold text-sm transition-all relative",
                  activeTab === 'activity' ? "text-blue-600" : "text-slate-400 hover:text-slate-600"
                )}
              >
                Activity Timeline
                {activeTab === 'activity' && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600 rounded-t-full" />}
              </button>
            </div>

            <div className="flex-1 p-8 overflow-y-auto">
              <AnimatePresence mode="wait">
                {activeTab === 'notes' && (
                  <motion.div 
                    key="notes"
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    className="space-y-8"
                  >
                    {/* Add Note Form */}
                    <form onSubmit={handleAddNote} className="space-y-4">
                      <div className="flex items-center gap-3 mb-2">
                        {(['doctor', 'nurse', 'coordinator'] as const).map((type) => (
                          <button
                            key={type}
                            type="button"
                            onClick={() => setNoteType(type)}
                            className={cn(
                              "px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all",
                              noteType === type ? "bg-blue-600 text-white shadow-lg shadow-blue-100" : "bg-slate-50 text-slate-500 hover:bg-slate-100"
                            )}
                          >
                            {type} Note
                          </button>
                        ))}
                      </div>
                      <div className="relative">
                        <textarea 
                          value={newNote}
                          onChange={(e) => setNewNote(e.target.value)}
                          placeholder="Write clinical or coordination notes here..."
                          className="w-full bg-slate-50 border-none rounded-[2rem] p-6 text-sm font-medium focus:ring-2 focus:ring-blue-500/20 transition-all min-h-[120px] resize-none"
                        />
                        <button 
                          type="submit"
                          disabled={!newNote.trim()}
                          className="absolute bottom-4 right-4 bg-blue-600 text-white p-3 rounded-2xl shadow-lg shadow-blue-200 hover:bg-blue-700 transition-all disabled:opacity-50"
                        >
                          <Plus className="w-5 h-5" />
                        </button>
                      </div>
                    </form>

                    <div className="space-y-6">
                      {notes.map((note) => (
                        <div key={note.id} className="bg-slate-50 rounded-3xl p-6 relative group border border-transparent hover:border-slate-100 transition-all">
                          <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center font-bold text-slate-600 uppercase text-xs">
                                {note.userRole.charAt(0)}
                              </div>
                              <div>
                                <p className="font-bold text-slate-900 text-sm">{note.userName}</p>
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{note.userRole} • {formatDateTime(note.createdAt)}</p>
                              </div>
                            </div>
                            <div className={cn(
                              "px-3 py-1 rounded-lg text-[10px] font-bold uppercase",
                              note.type === 'doctor' ? "bg-blue-100 text-blue-600" :
                              note.type === 'nurse' ? "bg-green-100 text-green-600" : "bg-orange-100 text-orange-600"
                            )}>
                              {note.type}
                            </div>
                          </div>
                          <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap">{note.content}</p>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}

                {activeTab === 'files' && (
                  <motion.div 
                    key="files"
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    className="h-full"
                  >
                    <div className="flex items-center justify-between mb-8">
                      <h4 className="font-bold text-slate-800">Uploaded Records</h4>
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="flex items-center gap-2 bg-blue-50 text-blue-600 px-4 py-2 rounded-xl font-bold text-sm hover:bg-blue-100 transition-all"
                      >
                        <Upload className="w-4 h-4" /> Upload New
                      </button>
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleFileUpload} 
                        className="hidden" 
                        accept=".pdf,image/*,.doc,.docx"
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {patient.attachments?.length ? patient.attachments.map((file, idx) => (
                        <div 
                          key={idx}
                          className="flex flex-col p-4 bg-slate-50 rounded-3xl border border-transparent hover:border-blue-100 hover:bg-blue-50/30 transition-all group"
                        >
                          <div className="flex items-center gap-4 mb-3">
                            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm text-blue-600 group-hover:scale-110 transition-transform">
                              {file.type === 'Link' ? <Globe className="w-6 h-6" /> : file.type.includes('image') ? <FilePlus className="w-6 h-6" /> : <FileText className="w-6 h-6" />}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-bold text-slate-800 text-sm truncate">{file.name}</p>
                              <div className="flex flex-wrap items-center gap-2">
                                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{formatDate(file.uploadedAt)}</p>
                                {file.uploadedBy && (
                                  <span className="text-[9px] bg-white text-slate-500 px-1.5 py-0.5 rounded border border-slate-100 font-bold uppercase">by {file.uploadedBy} ({file.uploaderRole})</span>
                                )}
                              </div>
                            </div>
                            <a 
                              href={file.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-2 bg-white rounded-lg text-blue-600 shadow-sm hover:shadow-md transition-all"
                            >
                              <Upload className="w-4 h-4 rotate-45" />
                            </a>
                          </div>
                          {file.description && (
                            <p className="text-xs text-slate-500 font-medium italic pl-1 border-l-2 border-slate-200 ml-1">
                              {file.description}
                            </p>
                          )}
                        </div>
                      )) : (
                        <div className="col-span-full py-20 text-center">
                          <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                            <FilePlus className="w-8 h-8 text-slate-300" />
                          </div>
                          <p className="text-slate-400 font-medium">No medical files uploaded yet.</p>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}

                {activeTab === 'activity' && (
                  <motion.div 
                    key="activity"
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                  >
                    <div className="space-y-8 relative">
                      <div className="absolute left-6 top-0 bottom-0 w-1 bg-slate-50" />
                      {activity.map((log) => (
                        <div key={log.id} className="relative pl-14">
                          <div className="absolute left-4 top-1 w-5 h-5 bg-white border-4 border-blue-500 rounded-full shadow-sm z-10" />
                          <div className="bg-slate-50 rounded-[1.5rem] p-6">
                            <div className="flex items-center justify-between mb-2">
                              <p className="font-bold text-slate-900 text-sm">{log.userName}</p>
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{formatDateTime(log.timestamp)}</span>
                            </div>
                            <p className="text-sm text-slate-500">
                              <span className="font-bold text-slate-800">{log.action}</span>
                            </p>
                            <p className="text-[10px] font-bold text-blue-600 uppercase tracking-widest mt-2">{log.userRole}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
      <AddPatientModal 
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        editPatient={patient}
      />
    </div>
  );
};

export default PatientDetail;
