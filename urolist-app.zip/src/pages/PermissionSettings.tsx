import React, { useEffect, useState } from 'react';
import { 
  ShieldCheck, 
  Save, 
  RotateCcw, 
  UserCircle, 
  Stethoscope, 
  HeartPulse, 
  Users,
  CheckCircle2,
  XCircle,
  AlertCircle
} from 'lucide-react';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface RolePermissions {
  canAddPatients: boolean;
  canEditPatients: boolean;
  canDeletePatients: boolean;
  canViewReports: boolean;
  canManageArchive: boolean;
  canAddNotes: boolean;
  canChangeStatus: boolean;
}

const DEFAULT_PERMISSIONS: Record<string, RolePermissions> = {
  doctor: {
    canAddPatients: true,
    canEditPatients: false,
    canDeletePatients: false,
    canViewReports: true,
    canManageArchive: false,
    canAddNotes: true,
    canChangeStatus: true,
  },
  nurse: {
    canAddPatients: false,
    canEditPatients: false,
    canDeletePatients: false,
    canViewReports: false,
    canManageArchive: false,
    canAddNotes: true,
    canChangeStatus: true,
  },
  coordinator: {
    canAddPatients: true,
    canEditPatients: true,
    canDeletePatients: false,
    canViewReports: true,
    canManageArchive: true,
    canAddNotes: true,
    canChangeStatus: true,
  }
};

const PermissionSettings: React.FC = () => {
  const { profile } = useAuth();
  const [permissions, setPermissions] = useState<Record<string, RolePermissions>>(DEFAULT_PERMISSIONS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchPermissions = async () => {
      try {
        const docRef = doc(db, 'settings', 'permissions');
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          setPermissions(snap.data().roles);
        }
      } catch (err) {
        console.error("Error fetching permissions:", err);
        toast.error("Failed to load custom permissions. Using defaults.");
      } finally {
        setLoading(false);
      }
    };
    fetchPermissions();
  }, []);

  const handleToggle = (role: string, field: keyof RolePermissions) => {
    setPermissions(prev => ({
      ...prev,
      [role]: {
        ...prev[role],
        [field]: !prev[role][field]
      }
    }));
  };

  const handleSync = async () => {
    if (profile?.role !== 'admin') return;
    setSaving(true);
    const loadingToast = toast.loading("Syncing permissions with system...");
    
    try {
      await setDoc(doc(db, 'settings', 'permissions'), {
        roles: permissions,
        updatedBy: profile.uid,
        updatedAt: serverTimestamp()
      });
      
      toast.success("Permissions synced and updated successfully", { id: loadingToast });
    } catch (err) {
      toast.error("Failed to sync permissions", { id: loadingToast });
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    if (window.confirm("Reset all permissions to system defaults?")) {
      setPermissions(DEFAULT_PERMISSIONS);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500" />
      </div>
    );
  }

  const permissionLabels: Record<keyof RolePermissions, string> = {
    canAddPatients: "Add New Patients",
    canEditPatients: "Edit Patient Details",
    canDeletePatients: "Permanently Delete",
    canViewReports: "View Statistics & Reports",
    canManageArchive: "Access Archive & Restore",
    canAddNotes: "Add Medical Notes",
    canChangeStatus: "Update Operation Status"
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-3">
            <ShieldCheck className="w-8 h-8 text-blue-600" /> Permission Metrics
          </h1>
          <p className="text-slate-500 font-medium mt-1">
            Configure exactly what each role is allowed to do in UroList.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={handleReset}
            className="px-6 py-3 bg-white border border-slate-200 text-slate-600 font-bold rounded-2xl hover:bg-slate-50 transition-all flex items-center gap-2"
          >
            <RotateCcw className="w-5 h-5" /> Reset Defaults
          </button>
          <button 
            disabled={saving}
            onClick={handleSync}
            className="px-8 py-3 bg-blue-600 text-white font-bold rounded-2xl shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-2 disabled:opacity-50"
          >
            <Save className="w-5 h-5" /> Sync & Save
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { id: 'doctor', label: 'Doctors', icon: Stethoscope, color: 'text-blue-500', bg: 'bg-blue-50' },
          { id: 'nurse', label: 'Nurses', icon: HeartPulse, color: 'text-rose-500', bg: 'bg-rose-50' },
          { id: 'coordinator', label: 'Coordinators', icon: Users, color: 'text-amber-500', bg: 'bg-amber-50' }
        ].map((role) => (
          <motion.div 
            key={role.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden"
          >
            <div className={cn("p-8 border-b border-slate-50 flex items-center gap-4", role.bg)}>
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                <role.icon className={cn("w-6 h-6", role.color)} />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-900 text-xl">{role.label}</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Level 2 Access</p>
              </div>
            </div>
            
            <div className="p-4 space-y-1">
              {(Object.keys(permissionLabels) as Array<keyof RolePermissions>).map((key) => (
                <button
                  key={key}
                  disabled={key === 'canDeletePatients' && role.id !== 'admin'} // Admin role is hardcoded 
                  onClick={() => handleToggle(role.id, key)}
                  className="w-full flex items-center justify-between p-4 rounded-2xl hover:bg-slate-50 transition-all group"
                >
                  <span className="text-sm font-bold text-slate-600 group-hover:text-slate-900 transition-colors">
                    {permissionLabels[key]}
                  </span>
                  {permissions[role.id][key] ? (
                    <CheckCircle2 className="w-6 h-6 text-green-500 fill-green-50" />
                  ) : (
                    <XCircle className="w-6 h-6 text-slate-200" />
                  )}
                </button>
              ))}
            </div>
            
            <div className="p-6 bg-slate-50/50 flex items-start gap-3 border-t border-slate-50">
              <AlertCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <p className="text-[10px] font-medium text-slate-400 italic">
                Changes will take effect for all {role.label} immediately after syncing.
              </p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="bg-amber-50 border border-amber-100 rounded-[2rem] p-8 flex items-start gap-6">
        <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-sm shrink-0">
          <ShieldCheck className="w-7 h-7 text-amber-500" />
        </div>
        <div>
          <h4 className="font-bold text-amber-900 text-lg mb-1">System-Level Security Notice</h4>
          <p className="text-amber-800/70 text-sm leading-relaxed">
            While these settings control the UI visibility and features, the core security is enforced by 
            <strong> Firestore Security Rules</strong>. Only users with the <span className="font-bold uppercase">Admin</span> role 
            stored in their profile document can bypass the primary restrictions regardless of these visual permission toggles.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PermissionSettings;
