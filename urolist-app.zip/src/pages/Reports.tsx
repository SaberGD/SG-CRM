import React, { useState, useEffect } from 'react';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Patient } from '../types';
import { formatDate, cn } from '../lib/utils';
import { 
  FileText, 
  Download, 
  Table as TableIcon, 
  BarChart3, 
  ChevronRight,
  Filter,
  PieChart as PieIcon,
  Activity
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { motion } from 'motion/react';
import toast from 'react-hot-toast';

const Reports: React.FC = () => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPatients = async () => {
      const snap = await getDocs(query(collection(db, 'patients'), orderBy('createdAt', 'desc')));
      setPatients(snap.docs.map(d => ({ id: d.id, ...d.data() } as Patient)));
      setLoading(false);
    };
    fetchPatients();
  }, []);

  const exportPDF = () => {
    const doc = new jsPDF() as any;
    doc.text('Urology Surgical Waiting List Report', 14, 20);
    doc.setFontSize(10);
    doc.text(`Generated on: ${new Date().toLocaleString()}`, 14, 25);

    const tableData = patients.map(p => [
      p.fullName,
      p.nationalId,
      p.department,
      p.priorityLevel,
      p.operationStatus,
      formatDate(p.createdAt)
    ]);

    doc.autoTable({
      head: [['Full Name', 'National ID', 'Department', 'Priority', 'Status', 'Date Added']],
      body: tableData,
      startY: 30,
      theme: 'striped',
      headStyles: { fillColor: [37, 99, 235] }
    });

    doc.save(`Urology_Waiting_List_${new Date().toISOString().split('T')[0]}.pdf`);
    toast.success("PDF exported successfully");
  };

  const exportExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(patients.map(p => ({
      'Full Name': p.fullName,
      'National ID': p.nationalId,
      'Department': p.department,
      'Priority': p.priorityLevel,
      'Status': p.operationStatus,
      'Insurance': p.insuranceType,
      'Diagnosis': p.diagnosis,
      'Phone': p.phoneNumber,
      'Date Added': formatDate(p.createdAt)
    })));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Patients");
    XLSX.writeFile(workbook, `Urology_Report_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast.success("Excel exported successfully");
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Reports & Analytics</h1>
        <p className="text-slate-500 font-medium mt-1">Export patient data and review surgical performance metrics.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col items-center text-center"
        >
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center mb-6">
            <FileText className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-extrabold text-slate-900 mb-2">Patient Records PDF</h3>
          <p className="text-slate-500 text-sm mb-8 leading-relaxed">
            Generate a formatted printable document containing all current waiting list entries with clinical status.
          </p>
          <button 
            onClick={exportPDF}
            className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl flex items-center justify-center gap-3 hover:bg-slate-800 transition-all shadow-lg shadow-slate-100"
          >
            <Download className="w-5 h-5" />
            Download PDF
          </button>
        </motion.div>

        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col items-center text-center"
        >
          <div className="w-16 h-16 bg-green-50 text-green-600 rounded-3xl flex items-center justify-center mb-6">
            <TableIcon className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-extrabold text-slate-900 mb-2">Master Patient List .xlsx</h3>
          <p className="text-slate-500 text-sm mb-8 leading-relaxed">
            Export raw patient data to Excel for advanced filtering, sorting, or custom hospital processing.
          </p>
          <button 
            onClick={exportExcel}
            className="w-full py-4 bg-green-600 text-white font-bold rounded-2xl flex items-center justify-center gap-3 hover:bg-green-700 transition-all shadow-lg shadow-green-50"
          >
            <Download className="w-5 h-5" />
            Export Excel
          </button>
        </motion.div>

        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col items-center text-center overflow-hidden relative"
        >
          <div className="w-16 h-16 bg-purple-50 text-purple-600 rounded-3xl flex items-center justify-center mb-6">
            <BarChart3 className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-extrabold text-slate-900 mb-2">Monthly Statistics</h3>
          <p className="text-slate-500 text-sm mb-8 leading-relaxed">
            Summary charts for surgical success rates, department performance, and waiting times.
          </p>
          <button 
            className="w-full py-4 bg-blue-50 text-blue-600 font-bold rounded-2xl flex items-center justify-center gap-3 hover:bg-blue-100 transition-all"
          >
            <PieIcon className="w-5 h-5" />
            View Live Stats
          </button>
        </motion.div>
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-100 p-8 shadow-sm">
        <h3 className="font-extrabold text-slate-900 text-lg mb-8 flex items-center gap-3">
          <Activity className="w-5 h-5 text-blue-600" />
          Available Data Exports
        </h3>
        <div className="space-y-3">
          {[
            { name: 'Daily Operation Schedule', format: 'PDF', status: 'Ready' },
            { name: 'Onco-urology Unit Review', format: 'Excel', status: 'Ready' },
            { name: 'Insurance Billing Summary', format: 'Excel', status: 'Restricted' },
            { name: 'Waiting List Mortality Review', format: 'PDF', status: 'Admin Only' }
          ].map((rpt) => (
            <div key={rpt.name} className="flex items-center justify-between p-4 hover:bg-slate-50 rounded-2xl transition-all cursor-pointer group border border-transparent hover:border-slate-100">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center font-bold text-[10px] text-slate-400">
                  {rpt.format}
                </div>
                <div>
                  <p className="font-bold text-slate-800">{rpt.name}</p>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{rpt.status}</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Reports;
