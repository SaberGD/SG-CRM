import React, { useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useUI } from '../context/UIContext';
import { User, Shield, Bell, Moon, Sun, Monitor, HelpCircle, Globe, Download, Upload, Database } from 'lucide-react';
import { cn } from '../lib/utils';
import { exportSystemData, importSystemData } from '../lib/backupService';
import Branding from '../components/Branding';
import toast from 'react-hot-toast';

const Settings: React.FC = () => {
  const { profile } = useAuth();
  const { t, theme, setTheme, language, setLanguage } = useUI();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const confirm = window.confirm("Are you sure you want to restore? This will overwrite existing data with the backup contents.");
      if (confirm) {
        await importSystemData(file);
      }
    }
  };

  return (
    <div className="space-y-8 pb-12">
      <div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">{t('settings')}</h1>
        <p className="text-slate-500 dark:text-slate-400 font-medium mt-1">Configure your workspace and review account permissions.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm p-8 text-center sticky top-8 transition-colors duration-300">
            <div className="w-24 h-24 bg-blue-600 rounded-[2.5rem] flex items-center justify-center text-white text-3xl font-extrabold mx-auto mb-6 shadow-2xl shadow-blue-200 dark:shadow-blue-900/20">
              {profile?.displayName?.charAt(0)}
            </div>
            <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white">{profile?.displayName}</h3>
            <p className="text-blue-600 dark:text-blue-400 font-bold uppercase text-xs tracking-widest mt-1">{profile?.role}</p>
            
            <div className="mt-8 pt-8 border-t border-slate-50 dark:border-slate-800 space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400 dark:text-slate-500 font-bold uppercase tracking-tight text-[10px]">Email</span>
                <span className="font-bold text-slate-700 dark:text-slate-300 truncate max-w-[150px]">{profile?.email}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400 dark:text-slate-500 font-bold uppercase tracking-tight text-[10px]">Status</span>
                <span className="text-green-500 font-bold">Active Profile</span>
              </div>
            </div>

            <button className="w-full mt-8 py-4 px-6 bg-slate-900 dark:bg-slate-800 text-white dark:text-slate-200 rounded-2xl font-bold hover:bg-slate-800 dark:hover:bg-slate-700 transition-all shadow-lg shadow-slate-100 dark:shadow-none">
              Edit Profile
            </button>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-8">
          <section className="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden transition-colors duration-300">
            <div className="p-8 border-b border-slate-100 dark:border-slate-800 flex items-center gap-4">
              <div className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center justify-center">
                <Monitor className="w-5 h-5 text-slate-600 dark:text-slate-400" />
              </div>
              <h3 className="font-extrabold text-slate-900 dark:text-white text-lg">Interface Preferences</h3>
            </div>
            <div className="p-8 space-y-6">
              <div className="flex items-center justify-between p-6 bg-slate-50 dark:bg-slate-800/50 rounded-2xl">
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">Dark Mode</p>
                  <p className="text-xs text-slate-400 dark:text-slate-500 font-medium leading-relaxed">Toggle between light and dark system themes.</p>
                </div>
                <div className="flex bg-white dark:bg-slate-800 p-1 rounded-xl shadow-inner border border-slate-100 dark:border-slate-700">
                  <button 
                    onClick={() => setTheme('light')}
                    className={cn(
                      "p-2 rounded-lg transition-all",
                      theme === 'light' ? "text-blue-600 bg-blue-50 dark:text-blue-400 dark:bg-blue-900/30 shadow-sm" : "text-slate-400 hover:text-slate-600"
                    )}
                  >
                    <Sun className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setTheme('dark')}
                    className={cn(
                      "p-2 rounded-lg transition-all",
                      theme === 'dark' ? "text-orange-500 bg-orange-50 dark:text-yellow-400 dark:bg-yellow-900/20 shadow-sm" : "text-slate-400 hover:text-slate-600"
                    )}
                  >
                    <Moon className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between p-6 bg-slate-50 dark:bg-slate-800/50 rounded-2xl cursor-pointer" onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-white dark:bg-slate-700 rounded-xl flex items-center justify-center shadow-sm">
                    <Globe className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">System Language</p>
                    <p className="text-xs text-slate-400 dark:text-slate-500 font-medium leading-relaxed">Choose your preferred display language.</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={cn("text-xs font-bold px-3 py-1.5 rounded-lg", language === 'en' ? "bg-blue-600 text-white" : "bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-300")}>EN</span>
                  <span className={cn("text-xs font-bold px-3 py-1.5 rounded-lg", language === 'ar' ? "bg-blue-600 text-white" : "bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-300")}>AR</span>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden transition-colors duration-300">
            <div className="p-8 border-b border-slate-100 dark:border-slate-800 flex items-center gap-4">
              <div className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center justify-center">
                <Bell className="w-5 h-5 text-slate-600 dark:text-slate-400" />
              </div>
              <h3 className="font-extrabold text-slate-900 dark:text-white text-lg">System Notifications</h3>
            </div>
            <div className="p-8 space-y-4">
              {[
                'New patient registered in my department',
                'Patient status changed to Operated',
                'Upcoming surgery reminders (24h before)',
                'System update & compliance alerts'
              ].map((item, idx) => (
                <div key={idx} className="flex items-center justify-between py-2 border-b border-slate-50 dark:border-slate-800 last:border-0">
                  <span className="text-sm font-medium text-slate-600 dark:text-slate-400">{item}</span>
                  <div className="w-10 h-5 bg-slate-100 dark:bg-slate-800 rounded-full relative cursor-not-allowed opacity-50">
                    <div className="absolute right-1 top-1 w-3 h-3 bg-white dark:bg-slate-600 rounded-full shadow-sm" />
                  </div>
                </div>
              ))}
            </div>
          </section>

          <div className="mt-12 flex items-center gap-3 p-6 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-[2rem] border border-blue-100 dark:border-blue-900/30 italic text-sm">
            <HelpCircle className="w-5 h-5 shrink-0" />
            <p>Some settings are managed at the organization level and cannot be modified personally.</p>
          </div>

          {profile?.role === 'admin' && (
            <div className="space-y-8">
              <section className="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden p-8 transition-colors duration-300">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center justify-center">
                    <Database className="w-5 h-5 text-slate-600 dark:text-slate-400" />
                  </div>
                  <h3 className="font-extrabold text-slate-900 dark:text-white text-lg">System Maintenance</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-6 border border-slate-100 dark:border-slate-800 rounded-[2rem] hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group">
                    <h4 className="font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                      <Download className="w-4 h-4 text-blue-600" />
                      Full System Backup
                    </h4>
                    <p className="text-xs text-slate-400 dark:text-slate-500 mb-4">Export all patients, users, and logs to a JSON file.</p>
                    <button 
                      onClick={exportSystemData}
                      className="text-sm font-bold text-blue-600 dark:text-blue-400 flex items-center gap-2"
                    >
                      Export Now
                    </button>
                  </div>

                  <div className="p-6 border border-slate-100 dark:border-slate-800 rounded-[2rem] hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                    <h4 className="font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                      <Upload className="w-4 h-4 text-orange-600" />
                      Restore from Backup
                    </h4>
                    <p className="text-xs text-slate-400 dark:text-slate-500 mb-4">Import data from a previously exported JSON file.</p>
                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      onChange={handleImport} 
                      accept=".json" 
                      className="hidden" 
                    />
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="text-sm font-bold text-orange-600 dark:text-orange-400 flex items-center gap-2"
                    >
                      Import File
                    </button>
                  </div>
                </div>
              </section>

              <div className="p-8 bg-orange-50 dark:bg-orange-950/20 rounded-[2rem] border border-orange-100 dark:border-orange-900/30 transition-colors duration-300">
                <h4 className="font-bold text-orange-800 dark:text-orange-400 mb-2">Development Tools</h4>
                <p className="text-sm text-orange-600 dark:text-orange-300/80 mb-6">Populate the database with sample patients, labels, and invitations. This action is irreversible.</p>
                <button 
                  onClick={async () => {
                    const { seedDatabase } = await import('../lib/seedData');
                    const success = await seedDatabase();
                    if (success) toast.success("Database seeded!");
                  }}
                  className="bg-orange-600 text-white font-bold px-8 py-4 rounded-2xl hover:bg-orange-700 transition-all shadow-xl shadow-orange-200 dark:shadow-none"
                >
                  Seed Sample Data
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="text-center pt-12 pb-6">
        <Branding />
      </div>
    </div>
  );
};

export default Settings;
