import React, { useEffect, useState } from 'react';
import { collection, query, orderBy, onSnapshot, limit } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { ActivityLog } from '../../types';
import { formatDateTime } from '../../lib/utils';
import { History, Search, Filter, User, Activity } from 'lucide-react';

const ActivityLogs: React.FC = () => {
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'activityLogs'), orderBy('timestamp', 'desc'), limit(100));
    const unsub = onSnapshot(q, (snap) => {
      setLogs(snap.docs.map(d => ({ id: d.id, ...d.data() } as ActivityLog)));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const filteredLogs = logs.filter(log => 
    log.userName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.patientName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Audit Logs</h1>
          <p className="text-slate-500 font-medium mt-1">Full system activity history for security and tracking.</p>
        </div>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search logs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl w-full md:w-64 focus:ring-2 focus:ring-blue-500/20"
          />
        </div>
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center">
              <History className="w-5 h-5 text-slate-600" />
            </div>
            <h3 className="font-extrabold text-slate-900">Recent Activity Timeline</h3>
          </div>
          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Last 100 entries</span>
        </div>

        <div className="divide-y divide-slate-50">
          {filteredLogs.map((log) => (
            <div key={log.id} className="p-6 hover:bg-slate-50/50 transition-colors flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center shrink-0">
                <User className="w-6 h-6 text-slate-400" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-bold text-slate-900">{log.userName}</span>
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest bg-blue-50 px-2 py-0.5 rounded-lg">{log.userRole}</span>
                </div>
                <p className="text-sm text-slate-600 font-medium">
                  {log.action}
                  {log.patientName && <span className="mx-2 text-slate-300">|</span>}
                  {log.patientName && <span className="text-blue-600 font-bold">Patient: {log.patientName}</span>}
                </p>
              </div>
              <div className="sm:text-right">
                <p className="text-xs font-bold text-slate-700">{formatDateTime(log.timestamp)}</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">{log.userEmail}</p>
              </div>
            </div>
          ))}

          {filteredLogs.length === 0 && !loading && (
            <div className="p-20 text-center">
              <p className="text-slate-400 font-medium">No logs found matching your search.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ActivityLogs;
