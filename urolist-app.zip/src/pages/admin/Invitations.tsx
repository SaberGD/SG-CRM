import React, { useEffect, useState } from 'react';
import { 
  collection, 
  query, 
  onSnapshot, 
  setDoc, 
  doc, 
  deleteDoc,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Invitation, UserRole } from '../../types';
import { 
  UserPlus, 
  Mail, 
  Shield, 
  Trash2, 
  MoreVertical, 
  Send,
  X,
  UserCheck,
  Clock,
  Ban
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';
import { cn } from '../../lib/utils';

const Invitations: React.FC = () => {
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { profile } = useAuth();

  // Form State
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [title, setTitle] = useState('');
  const [role, setRole] = useState<UserRole>('doctor');

  useEffect(() => {
    const q = query(collection(db, 'invitations'));
    const unsub = onSnapshot(q, (snap) => {
      setInvitations(snap.docs.map(d => ({ id: d.id, ...d.data() } as Invitation)));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !name.trim() || !profile) return;

    try {
      const invitation: Omit<Invitation, 'id'> = {
        email: email.toLowerCase().trim(),
        name: name.trim(),
        title: title.trim(),
        role,
        status: 'pending',
        invitedBy: profile.displayName,
        createdAt: new Date().toISOString()
      };

      await setDoc(doc(db, 'invitations', invitation.email), invitation);
      toast.success("Invitation sent successfully");
      setIsModalOpen(false);
      setEmail('');
      setName('');
      setTitle('');
    } catch (err) {
      toast.error("Failed to send invitation");
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to revoke this invitation?")) return;
    try {
      await deleteDoc(doc(db, 'invitations', id));
      toast.success("Invitation revoked");
    } catch (err) {
      toast.error("Failed to revoke invitation");
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">System Invitations</h1>
          <p className="text-slate-500 font-medium mt-1">Manage team access and invite new medical staff.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-2xl font-bold shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all"
        >
          <UserPlus className="w-5 h-5" />
          Invite Staff Member
        </button>
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100">
            <tr>
              <th className="px-8 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">User Details</th>
              <th className="px-6 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Assigned Role</th>
              <th className="px-6 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</th>
              <th className="px-6 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right px-10">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {invitations.map((inv) => (
              <tr key={inv.email} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-8 py-5">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center">
                      <Mail className="w-5 h-5 text-slate-400" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">{inv.name || 'No Name'}</p>
                      <p className="text-[10px] text-slate-500 font-medium">{inv.email} • {inv.title || 'No Title'}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-5">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-blue-500" />
                    <span className="text-sm font-bold text-slate-700 capitalize">{inv.role}</span>
                  </div>
                </td>
                <td className="px-6 py-5">
                  <div className={cn(
                    "flex items-center gap-2 px-3 py-1 rounded-xl text-[10px] font-bold uppercase tracking-tight w-fit",
                    inv.status === 'pending' ? "bg-orange-50 text-orange-600" :
                    inv.status === 'accepted' ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"
                  )}>
                    {inv.status === 'pending' ? <Clock className="w-3 h-3" /> : 
                     inv.status === 'accepted' ? <UserCheck className="w-3 h-3" /> : <Ban className="w-3 h-3" />}
                    {inv.status}
                  </div>
                </td>
                <td className="px-6 py-5 text-right px-10">
                  <button 
                    onClick={() => handleDelete(inv.email)}
                    className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Invite Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg bg-white rounded-[2.5rem] shadow-2xl z-[70] overflow-hidden border border-slate-100"
            >
              <div className="p-8 border-b border-slate-100 flex items-center justify-between">
                <h2 className="text-2xl font-extrabold text-slate-900">New Invitation</h2>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition-all"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleInvite} className="p-8 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Full Name</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g., Dr. Ahmed Ali"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-4 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 ml-1">Position / Title</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g., Senior Urologist"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full px-4 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 ml-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input 
                      type="email" 
                      required
                      placeholder="e.g., doctor@hospital.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 border-none rounded-2xl text-slate-800 placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-sm font-bold text-slate-700 ml-1">System Role</label>
                  <div className="grid grid-cols-2 gap-3">
                    {(['doctor', 'nurse', 'coordinator', 'admin'] as const).map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setRole(r)}
                        className={cn(
                          "flex items-center gap-3 p-4 rounded-2xl border-2 transition-all text-left",
                          role === r 
                            ? "bg-blue-50 border-blue-600 text-blue-700 shadow-lg shadow-blue-100" 
                            : "bg-white border-slate-100 text-slate-500 hover:border-slate-200"
                        )}
                      >
                        <Shield className={cn("w-5 h-5", role === r ? "text-blue-600" : "text-slate-300")} />
                        <span className="font-bold text-sm capitalize">{r}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="bg-blue-50/50 p-4 rounded-2xl">
                  <p className="text-xs text-blue-600 font-medium leading-relaxed italic">
                    The user will be able to sign in using their Google account only if their email matches this invitation.
                  </p>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center justify-center gap-3"
                >
                  <Send className="w-5 h-5" />
                  Send Invitation
                </button>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Invitations;
