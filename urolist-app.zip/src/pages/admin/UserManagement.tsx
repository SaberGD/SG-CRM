import React, { useEffect, useState } from 'react';
import { 
  collection, 
  query, 
  onSnapshot, 
  updateDoc, 
  doc 
} from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { UserProfile } from '../../types';
import { Users, Shield, Mail, Calendar, Power, Trash2, Search } from 'lucide-react';
import { formatDate, cn } from '../../lib/utils';
import toast from 'react-hot-toast';

const UserManagement: React.FC = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'users'));
    const unsub = onSnapshot(q, (snap) => {
      setUsers(snap.docs.map(d => (d.data() as UserProfile)));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const toggleUserStatus = async (userId: string, currentStatus: boolean) => {
    try {
      await updateDoc(doc(db, 'users', userId), { active: !currentStatus });
      toast.success(`User access ${!currentStatus ? 'enabled' : 'disabled'}`);
    } catch (err) {
      toast.error("Failed to update user status");
    }
  };

  const filteredUsers = users.filter(u => 
    u.email.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.displayName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Team Management</h1>
          <p className="text-slate-500 font-medium mt-1">Control access permissions and monitor active staff.</p>
        </div>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search team member..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl w-full md:w-64 focus:ring-2 focus:ring-blue-500/20"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredUsers.map((user) => (
          <div key={user.uid} className="bg-white rounded-[2rem] border border-slate-100 shadow-sm p-6 hover:shadow-xl hover:shadow-slate-200/50 transition-all group">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center font-bold text-slate-600 text-lg">
                  {user.displayName.charAt(0)}
                </div>
                <div>
                  <p className="font-extrabold text-slate-900">{user.displayName}</p>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-tight">{user.role}</p>
                </div>
              </div>
              <button 
                onClick={() => toggleUserStatus(user.uid, user.active)}
                className={cn(
                  "p-2.5 rounded-xl transition-all",
                  user.active ? "bg-green-50 text-green-600 hover:bg-green-100" : "bg-red-50 text-red-600 hover:bg-red-100"
                )}
                title={user.active ? 'Deactivate User' : 'Activate User'}
              >
                <Power className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3 text-slate-500">
                <Mail className="w-4 h-4 text-slate-300" />
                <span className="text-sm font-medium truncate">{user.email}</span>
              </div>
              <div className="flex items-center gap-3 text-slate-500">
                <Calendar className="w-4 h-4 text-slate-300" />
                <span className="text-sm font-medium">Joined {formatDate(user.createdAt)}</span>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-50 flex items-center justify-between">
              <span className={cn(
                "flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest",
                user.active ? "text-green-500" : "text-red-500"
              )}>
                <div className={cn("w-1.5 h-1.5 rounded-full mb-0.5", user.active ? "bg-green-500" : "bg-red-500")} />
                {user.active ? 'Active' : 'Disabled'}
              </span>
              <button className="text-[10px] font-bold text-slate-400 hover:text-red-500 uppercase tracking-widest">
                Delete Profile
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UserManagement;
