import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Patient, PatientNote, ActivityLog, Label, UserRole } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';

// Activity Logging
export const logActivity = async (action: string, patientId?: string, patientName?: string, metadata?: any) => {
  const user = auth.currentUser;
  
  const log: any = {
    userId: user?.uid || 'system',
    userName: user?.displayName || 'Unknown',
    userEmail: user?.email || 'Unknown',
    userRole: 'coordinator', // Fallback
    action,
    timestamp: serverTimestamp(),
  };

  if (patientId) log.patientId = patientId;
  if (patientName) log.patientName = patientName;
  if (metadata !== undefined && metadata !== null) log.metadata = metadata;

  try {
    const logRef = collection(db, 'activityLogs');
    await addDoc(logRef, log);
  } catch (error) {
    console.error('Logging failed:', error);
  }
};

// Patients API
export const patientService = {
  async getAll() {
    const p = 'patients';
    try {
      const q = query(collection(db, p), orderBy('createdAt', 'desc'));
      const snap = await getDocs(q);
      return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Patient));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, p);
    }
  },

  async create(patient: Omit<Patient, 'id' | 'createdAt' | 'updatedAt'>) {
    const p = 'patients';
    try {
      const docRef = await addDoc(collection(db, p), {
        ...patient,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await logActivity('Created Patient', docRef.id, patient.fullName);
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, p);
    }
  },

  async update(id: string, data: Partial<Patient>) {
    const p = `patients/${id}`;
    try {
      const ref = doc(db, 'patients', id);
      await updateDoc(ref, {
        ...data,
        updatedAt: serverTimestamp(),
      });
      await logActivity('Updated Patient', id, (data as any).fullName);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, p);
    }
  },

  async delete(id: string) {
    const p = `patients/${id}`;
    try {
      await deleteDoc(doc(db, 'patients', id));
      await logActivity('Deleted Patient', id);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, p);
    }
  }
};

// Notes API
export const noteService = {
  async addNote(patientId: string, note: Omit<PatientNote, 'id' | 'createdAt'>) {
    const p = `patients/${patientId}/notes`;
    try {
      const ref = await addDoc(collection(db, 'patients', patientId, 'notes'), {
        ...note,
        createdAt: serverTimestamp(),
      });
      await logActivity('Added Note', patientId);
      return ref.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, p);
    }
  }
};
