export type UserRole = 'admin' | 'doctor' | 'nurse' | 'coordinator';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  title?: string;
  role: UserRole;
  active: boolean;
  createdAt: string;
  lastLogin: string;
}

export interface Invitation {
  id?: string;
  email: string;
  name: string;
  title: string;
  role: UserRole;
  status: 'pending' | 'accepted' | 'revoked';
  invitedBy: string;
  createdAt: string;
}

export type DepartmentType = 'Onco-urology' | 'Andrology' | 'Female urology' | 'Pediatric urology';
export type InsuranceType = 'State Funding' | 'Health Insurance' | 'Private' | 'Other';
export type PriorityLevel = 'Urgent' | 'Moderate' | 'Routine';
export type OperationStatus = 'Waiting' | 'Scheduled' | 'Operated' | 'Cancelled';

export interface Patient {
  id?: string;
  fullName: string;
  age: number;
  gender: 'Male' | 'Female';
  address: string;
  phoneNumber: string;
  secondaryPhoneNumbers?: string[];
  hasWhatsapp: boolean;
  whatsappNumber?: string;
  nationalId: string;
  department: DepartmentType;
  diagnosis: string;
  insuranceType: InsuranceType;
  insuranceOtherDetails?: string;
  priorityLevel: PriorityLevel;
  operationStatus: OperationStatus;
  scheduledDate?: any; // Firestore Timestamp
  completedAt?: any; // Firestore Timestamp
  createdBy: string;
  createdByName?: string;
  createdByRole?: UserRole;
  assignedDoctorId?: string;
  labels: string[];
  attachments: Attachment[];
  createdAt: any;
  updatedAt: any;
}

export interface Attachment {
  name: string;
  url: string;
  type: string;
  description?: string;
  uploadedAt: string;
  uploadedBy?: string;
  uploaderRole?: UserRole;
}

export interface PatientNote {
  id?: string;
  patientId: string;
  content: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  type: 'doctor' | 'nurse' | 'coordinator';
  createdAt: any;
}

export interface ActivityLog {
  id?: string;
  userId: string;
  userName: string;
  userEmail: string;
  userRole: UserRole;
  action: string;
  patientId?: string;
  patientName?: string;
  timestamp: any;
  metadata?: any;
}

export interface Label {
  id?: string;
  name: string;
  color: string;
  description?: string;
}
